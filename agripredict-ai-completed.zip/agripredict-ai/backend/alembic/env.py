from logging.config import fileConfig
from alembic import context
from app.database.session import Base
from app.models import *
from app.core.config import settings
config=context.config
config.set_main_option("sqlalchemy.url",settings.database_url.replace('%','%%'))
if config.config_file_name:
    try: fileConfig(config.config_file_name)
    except (KeyError, ValueError): pass
target_metadata=Base.metadata
def run_migrations_offline():
    context.configure(url=settings.database_url,target_metadata=target_metadata,literal_binds=True,compare_type=True); 
    with context.begin_transaction(): context.run_migrations()
def run_migrations_online():
    from sqlalchemy import engine_from_config
    connectable=engine_from_config({"sqlalchemy.url":settings.database_url},prefix="sqlalchemy.",pool_pre_ping=True)
    with connectable.connect() as connection:
        context.configure(connection=connection,target_metadata=target_metadata,compare_type=True)
        with context.begin_transaction(): context.run_migrations()
if context.is_offline_mode(): run_migrations_offline()
else: run_migrations_online()
