"""ADBMS integrity, audit, indexes, views, functions, procedure and triggers.

Revision ID: 0002_adbms_features
Revises: 0001_initial
"""
from alembic import op
import sqlalchemy as sa

revision = "0002_adbms_features"
down_revision = "0001_initial"
branch_labels = None
depends_on = None


def upgrade():
    bind = op.get_bind()
    dialect = bind.dialect.name

    # Application-level timestamp columns.
    for table in ("farms", "soil_tests"):
        op.add_column(table, sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True))
        op.execute(sa.text(f"UPDATE {table} SET updated_at = created_at WHERE updated_at IS NULL"))
        if dialect != "sqlite":
            op.alter_column(table, "updated_at", nullable=False)

    op.create_table(
        "audit_logs",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("table_name", sa.String(100), nullable=False),
        sa.Column("record_id", sa.Integer(), nullable=True),
        sa.Column("action", sa.String(20), nullable=False),
        sa.Column("old_data", sa.Text(), nullable=True),
        sa.Column("new_data", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    indexes = [
        ("ix_users_role", "users", ["role"]),
        ("ix_farms_owner_id", "farms", ["owner_id"]),
        ("ix_farms_location", "farms", ["latitude", "longitude"]),
        ("ix_fields_farm_id", "fields", ["farm_id"]),
        ("ix_soil_tests_farm_created", "soil_tests", ["farm_id", "created_at"]),
        ("ix_soil_readings_farm_recorded", "soil_readings", ["farm_id", "recorded_at"]),
        ("ix_weather_farm_recorded", "weather_data", ["farm_id", "recorded_at"]),
        ("ix_crop_predictions_farm_created", "crop_predictions", ["farm_id", "created_at"]),
        ("ix_yield_predictions_farm_created", "yield_predictions", ["farm_id", "created_at"]),
        ("ix_irrigation_farm_created", "irrigation_predictions", ["farm_id", "created_at"]),
        ("ix_disease_farm_created", "disease_scans", ["farm_id", "created_at"]),
        ("ix_alerts_farm_read_created", "alerts", ["farm_id", "is_read", "created_at"]),
        ("ix_reports_farm_created", "reports", ["farm_id", "created_at"]),
        ("ix_chat_history_user_created", "chat_history", ["user_id", "created_at"]),
        ("ix_chat_history_farm_created", "chat_history", ["farm_id", "created_at"]),
        ("ix_audit_logs_table_record", "audit_logs", ["table_name", "record_id"]),
        ("ix_audit_logs_created", "audit_logs", ["created_at"]),
    ]
    for name, table, cols in indexes:
        try:
            op.create_index(name, table, cols)
        except Exception:
            pass

    if dialect == "sqlite":
        # SQLite test adapters do not support ALTER TABLE constraints consistently.
        # PostgreSQL is the primary database and receives the full constraint set below.
        return

    op.create_unique_constraint("uq_farms_owner_name", "farms", ["owner_id", "name"])
    op.create_unique_constraint("uq_fields_farm_name", "fields", ["farm_id", "name"])

    if dialect != "postgresql":
        return

    # PostgreSQL-specific ADBMS objects.
    op.execute("""
        ALTER TABLE users ADD CONSTRAINT ck_users_role CHECK (role IN ('farmer','expert','admin'));
        ALTER TABLE farms ADD CONSTRAINT ck_farms_area_positive CHECK (area_acres > 0);
        ALTER TABLE farms ADD CONSTRAINT ck_farms_latitude CHECK (latitude BETWEEN -90 AND 90);
        ALTER TABLE farms ADD CONSTRAINT ck_farms_longitude CHECK (longitude BETWEEN -180 AND 180);
        ALTER TABLE fields ADD CONSTRAINT ck_fields_area_positive CHECK (area_acres > 0);
        ALTER TABLE soil_tests ADD CONSTRAINT ck_soil_nitrogen CHECK (nitrogen BETWEEN 0 AND 1000);
        ALTER TABLE soil_tests ADD CONSTRAINT ck_soil_phosphorus CHECK (phosphorus BETWEEN 0 AND 1000);
        ALTER TABLE soil_tests ADD CONSTRAINT ck_soil_potassium CHECK (potassium BETWEEN 0 AND 1000);
        ALTER TABLE soil_tests ADD CONSTRAINT ck_soil_ph CHECK (ph BETWEEN 0 AND 14);
        ALTER TABLE soil_tests ADD CONSTRAINT ck_soil_organic_carbon CHECK (organic_carbon BETWEEN 0 AND 20);
        ALTER TABLE soil_tests ADD CONSTRAINT ck_soil_moisture CHECK (moisture BETWEEN 0 AND 100);
        ALTER TABLE soil_tests ADD CONSTRAINT ck_soil_source CHECK (source IN ('manual','ocr','uploaded_report','demo'));
        ALTER TABLE yield_predictions ADD CONSTRAINT ck_yield_nonnegative CHECK (yield_tph >= 0);
        ALTER TABLE yield_predictions ADD CONSTRAINT ck_production_nonnegative CHECK (total_production_tonnes >= 0);
    """)

    op.execute("""
    CREATE OR REPLACE FUNCTION fn_touch_updated_at() RETURNS trigger AS $$
    BEGIN
      NEW.updated_at = CURRENT_TIMESTAMP;
      RETURN NEW;
    END; $$ LANGUAGE plpgsql;
    """)
    op.execute("""
    CREATE OR REPLACE FUNCTION fn_audit_row() RETURNS trigger AS $$
    BEGIN
      IF TG_OP = 'INSERT' THEN
        INSERT INTO audit_logs(table_name, record_id, action, new_data, created_at)
        VALUES (TG_TABLE_NAME, NEW.id, TG_OP, to_jsonb(NEW)::text, CURRENT_TIMESTAMP);
        RETURN NEW;
      ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO audit_logs(table_name, record_id, action, old_data, new_data, created_at)
        VALUES (TG_TABLE_NAME, NEW.id, TG_OP, to_jsonb(OLD)::text, to_jsonb(NEW)::text, CURRENT_TIMESTAMP);
        RETURN NEW;
      ELSE
        INSERT INTO audit_logs(table_name, record_id, action, old_data, created_at)
        VALUES (TG_TABLE_NAME, OLD.id, TG_OP, to_jsonb(OLD)::text, CURRENT_TIMESTAMP);
        RETURN OLD;
      END IF;
    END; $$ LANGUAGE plpgsql;
    """)
    op.execute("""
    CREATE OR REPLACE FUNCTION fn_soil_status(p_ph numeric, p_moisture numeric, p_organic_carbon numeric)
    RETURNS text AS $$
    BEGIN
      IF p_ph BETWEEN 5.5 AND 7.5 AND p_moisture BETWEEN 25 AND 70 AND p_organic_carbon >= 0.5 THEN
        RETURN 'Good';
      ELSIF p_ph BETWEEN 5 AND 8 AND p_moisture BETWEEN 15 AND 85 THEN
        RETURN 'Needs attention';
      END IF;
      RETURN 'Critical';
    END; $$ LANGUAGE plpgsql IMMUTABLE;
    """)
    op.execute("""
    CREATE OR REPLACE FUNCTION fn_farm_health_score(p_ph numeric, p_moisture numeric, p_humidity numeric)
    RETURNS integer AS $$
    DECLARE score numeric;
    BEGIN
      score := 70 + ((LEAST(p_moisture, 60) - 40) * 0.25)
             + CASE WHEN p_ph BETWEEN 5.5 AND 7.5 THEN 8 ELSE -8 END
             - CASE WHEN p_humidity > 85 THEN 8 ELSE 0 END;
      RETURN GREATEST(0, LEAST(100, ROUND(score)))::integer;
    END; $$ LANGUAGE plpgsql IMMUTABLE;
    """)
    op.execute("""
    CREATE OR REPLACE PROCEDURE sp_finalize_yield_prediction(
      p_farm_id integer, p_crop varchar, p_yield_tph numeric, p_total_production_tonnes numeric
    ) LANGUAGE plpgsql AS $$
    BEGIN
      INSERT INTO yield_predictions(farm_id, crop, yield_tph, total_production_tonnes, created_at)
      VALUES (p_farm_id, p_crop, p_yield_tph, p_total_production_tonnes, CURRENT_TIMESTAMP);
    END; $$;
    """)

    for table in ("farms", "soil_tests"):
        op.execute(f"DROP TRIGGER IF EXISTS trg_{table}_updated_at ON {table}")
        op.execute(f"CREATE TRIGGER trg_{table}_updated_at BEFORE UPDATE ON {table} FOR EACH ROW EXECUTE FUNCTION fn_touch_updated_at()")
    for table in ("users", "farms", "fields", "soil_tests", "soil_readings", "weather_data", "crop_predictions", "yield_predictions", "irrigation_predictions", "disease_scans", "alerts", "reports", "chat_history"):
        op.execute(f"DROP TRIGGER IF EXISTS trg_{table}_audit ON {table}")
        op.execute(f"CREATE TRIGGER trg_{table}_audit AFTER INSERT OR UPDATE OR DELETE ON {table} FOR EACH ROW EXECUTE FUNCTION fn_audit_row()")

    op.execute("""
    CREATE OR REPLACE VIEW farm_summary AS
    SELECT f.id AS farm_id, f.owner_id, f.name, f.location, f.area_acres, f.current_crop, f.season,
           COUNT(DISTINCT fi.id) AS field_count,
           COUNT(DISTINCT cp.id) AS crop_prediction_count,
           COUNT(DISTINCT yp.id) AS yield_prediction_count,
           COUNT(DISTINCT a.id) FILTER (WHERE a.is_read = false) AS unread_alert_count
    FROM farms f
    LEFT JOIN fields fi ON fi.farm_id = f.id
    LEFT JOIN crop_predictions cp ON cp.farm_id = f.id
    LEFT JOIN yield_predictions yp ON yp.farm_id = f.id
    LEFT JOIN alerts a ON a.farm_id = f.id
    GROUP BY f.id;
    """)
    op.execute("""
    CREATE OR REPLACE VIEW latest_soil_status AS
    SELECT DISTINCT ON (s.farm_id) s.farm_id, s.id AS soil_test_id, s.nitrogen, s.phosphorus, s.potassium,
           s.ph, s.organic_carbon, s.moisture, s.source, s.verified, s.created_at,
           fn_soil_status(s.ph, s.moisture, s.organic_carbon) AS soil_status
    FROM soil_tests s ORDER BY s.farm_id, s.created_at DESC, s.id DESC;
    """)
    op.execute("""
    CREATE OR REPLACE VIEW prediction_summary AS
    SELECT f.id AS farm_id, f.name,
           (SELECT cp.recommended_crop FROM crop_predictions cp WHERE cp.farm_id=f.id ORDER BY cp.created_at DESC LIMIT 1) AS latest_crop,
           (SELECT cp.confidence FROM crop_predictions cp WHERE cp.farm_id=f.id ORDER BY cp.created_at DESC LIMIT 1) AS crop_confidence,
           (SELECT yp.yield_tph FROM yield_predictions yp WHERE yp.farm_id=f.id ORDER BY yp.created_at DESC LIMIT 1) AS latest_yield_tph,
           (SELECT ip.required FROM irrigation_predictions ip WHERE ip.farm_id=f.id ORDER BY ip.created_at DESC LIMIT 1) AS irrigation_required
    FROM farms f;
    """)
    op.execute("""
    CREATE OR REPLACE VIEW alert_summary AS
    SELECT a.id, a.farm_id, f.owner_id, a.kind, a.title, a.message, a.is_read, a.created_at
    FROM alerts a JOIN farms f ON f.id=a.farm_id;
    """)


def downgrade():
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        for table in ("farms", "soil_tests"):
            op.execute(f"DROP TRIGGER IF EXISTS trg_{table}_updated_at ON {table}")
        for table in ("users", "farms", "fields", "soil_tests", "soil_readings", "weather_data", "crop_predictions", "yield_predictions", "irrigation_predictions", "disease_scans", "alerts", "reports", "chat_history"):
            op.execute(f"DROP TRIGGER IF EXISTS trg_{table}_audit ON {table}")
        for view in ("alert_summary", "prediction_summary", "latest_soil_status", "farm_summary"):
            op.execute(f"DROP VIEW IF EXISTS {view}")
        op.execute("DROP PROCEDURE IF EXISTS sp_finalize_yield_prediction(integer, varchar, numeric, numeric)")
        op.execute("DROP FUNCTION IF EXISTS fn_farm_health_score(numeric,numeric,numeric)")
        op.execute("DROP FUNCTION IF EXISTS fn_soil_status(numeric,numeric,numeric)")
        op.execute("DROP FUNCTION IF EXISTS fn_audit_row()")
        op.execute("DROP FUNCTION IF EXISTS fn_touch_updated_at()")
        for name, table in [("uq_farms_owner_name", "farms"), ("uq_fields_farm_name", "fields")]:
            try:
                op.drop_constraint(name, table, type_="unique")
            except Exception:
                pass
    for name, table in [
        ("ix_users_role", "users"), ("ix_farms_owner_id", "farms"), ("ix_farms_location", "farms"),
        ("ix_fields_farm_id", "fields"), ("ix_soil_tests_farm_created", "soil_tests"),
        ("ix_soil_readings_farm_recorded", "soil_readings"), ("ix_weather_farm_recorded", "weather_data"),
        ("ix_crop_predictions_farm_created", "crop_predictions"), ("ix_yield_predictions_farm_created", "yield_predictions"),
        ("ix_irrigation_farm_created", "irrigation_predictions"), ("ix_disease_farm_created", "disease_scans"),
        ("ix_alerts_farm_read_created", "alerts"), ("ix_reports_farm_created", "reports"),
        ("ix_chat_history_user_created", "chat_history"), ("ix_chat_history_farm_created", "chat_history"),
        ("ix_audit_logs_table_record", "audit_logs"), ("ix_audit_logs_created", "audit_logs")]:
        try:
            op.drop_index(name, table_name=table)
        except Exception:
            pass
    op.drop_table("audit_logs")
    op.drop_column("farms", "updated_at")
    op.drop_column("soil_tests", "updated_at")
