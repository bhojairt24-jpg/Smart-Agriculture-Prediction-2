from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.database.session import engine
from app.models import *
from app.api.routes import auth, farms, soil, predictions, disease, weather, dashboard, alerts, assistant, reports, admin

Path(settings.upload_dir).mkdir(parents=True, exist_ok=True)
Path(settings.report_dir).mkdir(parents=True, exist_ok=True)

app = FastAPI(title=settings.app_name, version="1.1.0", description="Smart agriculture decision-support platform")
app.add_middleware(
    CORSMiddleware,
    allow_origins=list(dict.fromkeys([settings.frontend_origin, "http://localhost:5173"])),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
for r in [auth.router, farms.router, soil.router, predictions.router, disease.router, weather.router, dashboard.router, alerts.router, assistant.router, reports.router, admin.router]:
    app.include_router(r)

@app.get("/")
def root():
    return {"name": settings.app_name, "status": "ok", "demo_mode": settings.demo_mode, "docs": "/docs"}

@app.get("/health")
def health():
    return {"status": "healthy"}
