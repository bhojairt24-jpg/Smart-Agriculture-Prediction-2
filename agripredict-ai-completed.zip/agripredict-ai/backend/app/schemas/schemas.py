from datetime import datetime
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

class UserRegister(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    role: str = "farmer"
    @field_validator("role")
    @classmethod
    def valid_role(cls, v):
        if v not in {"farmer", "expert"}: raise ValueError("Self-registration is limited to farmer and expert roles")
        return v

class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)

class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int; name: str; email: EmailStr; role: str; created_at: datetime

class TokenOut(BaseModel):
    access_token: str; token_type: str = "bearer"; user: UserOut

class FarmBase(BaseModel):
    name: str = Field(min_length=2, max_length=150)
    location: str = Field(min_length=2, max_length=200)
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    area_acres: float = Field(gt=0, le=100000)
    soil_type: str = Field(min_length=2, max_length=80)
    current_crop: str = Field(min_length=2, max_length=80)
    season: str = Field(min_length=2, max_length=50)

class FarmCreate(FarmBase): pass
class FarmUpdate(FarmBase): pass
class FarmOut(FarmBase):
    model_config = ConfigDict(from_attributes=True)
    id: int; owner_id: int

class FieldCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    area_acres: float = Field(gt=0, le=100000)
    crop: str = Field(min_length=2, max_length=80)

class FieldOut(FieldCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    farm_id: int

class SoilInput(BaseModel):
    farm_id: int
    source: str = "manual"
    nitrogen: float = Field(ge=0, le=1000)
    phosphorus: float = Field(ge=0, le=1000)
    potassium: float = Field(ge=0, le=1000)
    ph: float = Field(ge=0, le=14)
    organic_carbon: float = Field(ge=0, le=20)
    moisture: float = Field(ge=0, le=100)
    verified: bool = False

    @field_validator("source")
    @classmethod
    def valid_source(cls, v):
        if v not in {"manual", "ocr", "uploaded_report", "demo"}:
            raise ValueError("Invalid soil data source")
        return v

class CropInput(BaseModel):
    farm_id: int
    nitrogen: float = Field(ge=0, le=1000)
    phosphorus: float = Field(ge=0, le=1000)
    potassium: float = Field(ge=0, le=1000)
    temperature: float = Field(ge=-20, le=60)
    humidity: float = Field(ge=0, le=100)
    ph: float = Field(ge=0, le=14)
    rainfall: float = Field(ge=0, le=5000)

class YieldInput(BaseModel):
    farm_id: int
    crop: str = Field(min_length=2, max_length=80)
    area_acres: float = Field(gt=0)
    rainfall: float = Field(ge=0, le=5000)
    temperature: float = Field(ge=-20, le=60)
    ph: float = Field(ge=0, le=14)
    nitrogen: float = Field(ge=0, le=1000)
    phosphorus: float = Field(ge=0, le=1000)
    potassium: float = Field(ge=0, le=1000)
    irrigation: bool = False
    season: str = "Kharif"

class IrrigationInput(BaseModel):
    farm_id: int
    soil_moisture: float = Field(ge=0, le=100)
    temperature: float = Field(ge=-20, le=60)
    humidity: float = Field(ge=0, le=100)
    crop: str = Field(min_length=2)
    growth_stage: str = Field(min_length=2)
    rain_probability: float = Field(ge=0, le=100)
    expected_rainfall: float = Field(ge=0, le=5000)

class AssistantInput(BaseModel):
    farm_id: int | None = None
    message: str = Field(min_length=1, max_length=2000)

class ReportInput(BaseModel):
    farm_id: int
