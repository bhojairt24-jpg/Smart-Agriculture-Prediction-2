from pathlib import Path
import json
import numpy as np
import pandas as pd
from app.core.config import settings
ART=Path(__file__).parent/"artifacts"
_model=None
_meta=None

def _load():
    global _model,_meta
    if _model is None:
        try:
            import joblib
            _model=joblib.load(ART/"crop_model.joblib")
            _meta=json.loads((ART/"crop_meta.json").read_text())
        except Exception:
            _model=None
    return _model

def predict(data):
    model=_load()
    features=[data[k] for k in ["nitrogen","phosphorus","potassium","temperature","humidity","ph","rainfall"]]
    if model is None:
        # Demo fallback is intentionally a transparent deterministic approximation.
        score={"Rice": 0.0,"Maize":0.0,"Chickpea":0.0,"Cotton":0.0}
        score["Rice"] += max(0,1-abs(data["ph"]-6.5)/3)+data["rainfall"]/300
        score["Maize"] += max(0,1-abs(data["ph"]-6.2)/3)+data["temperature"]/40
        score["Chickpea"] += max(0,1-abs(data["ph"]-7.0)/3)+(100-data["humidity"])/100
        score["Cotton"] += max(0,1-abs(data["ph"]-7.0)/3)+data["temperature"]/50
        total=sum(score.values()) or 1
        probs={k:v/total for k,v in score.items()}
        ordered=sorted(probs.items(),key=lambda x:x[1],reverse=True)
        return {"recommended_crop":ordered[0][0],"confidence":round(ordered[0][1]*100,1),"alternatives":[{"crop":k,"confidence":round(v*100,1)} for k,v in ordered[1:]],"demo_mode":True}
    arr=pd.DataFrame([features], columns=["nitrogen","phosphorus","potassium","temperature","humidity","ph","rainfall"])
    pred=model.predict(arr)[0]
    if hasattr(model,"predict_proba"):
        probs=model.predict_proba(arr)[0]; classes=model.classes_; ranked=sorted(zip(classes,probs),key=lambda x:x[1],reverse=True)
        return {"recommended_crop":str(pred),"confidence":round(float(ranked[0][1])*100,1),"alternatives":[{"crop":str(c),"confidence":round(float(p)*100,1)} for c,p in ranked[1:4]],"demo_mode":False}
    return {"recommended_crop":str(pred),"confidence":None,"alternatives":[],"demo_mode":False}
