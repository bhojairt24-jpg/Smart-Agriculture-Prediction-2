from pathlib import Path
from PIL import Image
from app.core.config import settings
ART=Path(__file__).parent/"artifacts"
_model=None; _classes=None

def analyze(path):
    global _model,_classes
    artifact=ART/"disease_mobilenetv2.pt"; meta=ART/"disease_classes.txt"
    if artifact.exists() and meta.exists():
        try:
            import torch
            from torchvision import models, transforms
            if _model is None:
                classes=[x.strip() for x in meta.read_text().splitlines() if x.strip()]; _classes=classes
                _model=models.mobilenet_v2(weights=None); _model.classifier[1]=torch.nn.Linear(_model.last_channel,len(classes)); _model.load_state_dict(torch.load(artifact,map_location="cpu")); _model.eval()
            im=Image.open(path).convert("RGB"); tf=transforms.Compose([transforms.Resize((224,224)),transforms.ToTensor(),transforms.Normalize([.485,.456,.406],[.229,.224,.225])]); x=tf(im).unsqueeze(0)
            import torch
            with torch.no_grad(): probs=torch.softmax(_model(x),dim=1)[0]; idx=int(probs.argmax())
            return {"disease":_classes[idx],"confidence":round(float(probs[idx])*100,1),"severity":"Moderate","guidance":"Remove affected leaves, avoid overhead watering, improve air circulation and monitor nearby plants.","demo_mode":False}
        except Exception:
            pass
    if settings.demo_mode:
        return {"disease":"Tomato Early Blight","confidence":94.6,"severity":"Moderate","guidance":"Remove affected leaves, avoid overhead watering, improve air circulation and monitor nearby plants.","demo_mode":True}
    raise RuntimeError("Disease model artifact is not available")
