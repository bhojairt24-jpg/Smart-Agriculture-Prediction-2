from pathlib import Path
import numpy as np
import pandas as pd
ART=Path(__file__).parent/"artifacts"
_model=None

def _load():
    global _model
    if _model is None:
        try:
            import joblib; _model=joblib.load(ART/"yield_model.joblib")
        except Exception: _model=None
    return _model

def predict(data):
    model=_load(); crop_map={"Rice":1,"Maize":2,"Chickpea":3,"Cotton":4,"Wheat":5}
    feats=[crop_map.get(data["crop"],0),data["rainfall"],data["temperature"],data["ph"],data["nitrogen"],data["phosphorus"],data["potassium"],int(data["irrigation"]),1 if data["season"].lower()=="kharif" else 0]
    if model is None:
        y=2.0+0.015*data["nitrogen"]+0.01*data["phosphorus"]+0.008*data["potassium"]+0.002*data["rainfall"]-0.15*abs(data["ph"]-6.5)+(0.6 if data["irrigation"] else 0)
        y=max(0.5,min(10,y))
        return {"yield_tph":round(y,2),"total_production_tonnes":round(y*data["area_acres"]*0.404686,2),"demo_mode":True}
    arr=pd.DataFrame([feats], columns=["crop","rainfall","temperature","ph","nitrogen","phosphorus","potassium","irrigation","season"])
    y=float(model.predict(arr)[0]); y=max(0,y)
    return {"yield_tph":round(y,2),"total_production_tonnes":round(y*data["area_acres"]*0.404686,2),"demo_mode":False}
