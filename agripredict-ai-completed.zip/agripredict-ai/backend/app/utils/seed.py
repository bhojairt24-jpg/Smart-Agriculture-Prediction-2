from datetime import datetime, timedelta, timezone
from app.database.session import Base, engine, SessionLocal
from app.models import User, Farm, SoilTest, SoilReading, Alert
from app.core.security import hash_password


def seed():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        now = datetime.now(timezone.utc)
        u = db.query(User).filter_by(email="demo@agripredict.ai").first()
        if not u:
            u = User(name="John Farmer", email="demo@agripredict.ai", password_hash=hash_password("Demo@12345"), role="farmer")
            db.add(u)
            db.flush()
        admin = db.query(User).filter_by(email="admin@agripredict.ai").first()
        if not admin:
            admin = User(name="AgriPredict Admin", email="admin@agripredict.ai", password_hash=hash_password("Admin@12345"), role="admin")
            db.add(admin)
        farm = db.query(Farm).filter_by(owner_id=u.id, name="Green Valley Farm").first()
        if not farm:
            farm = Farm(owner_id=u.id, name="Green Valley Farm", location="Pune, Maharashtra", latitude=18.5204, longitude=73.8567, area_acres=5, soil_type="Loamy", current_crop="Rice", season="Kharif")
            db.add(farm)
            db.flush()
            db.add(SoilTest(farm_id=farm.id, nitrogen=82, phosphorus=35, potassium=48, ph=6.7, organic_carbon=.72, moisture=42, source="demo", verified=True))
            for i, moisture in enumerate([46, 42, 40, 48, 44, 53, 50, 42]):
                db.add(SoilReading(farm_id=farm.id, moisture=moisture, recorded_at=now - timedelta(days=7-i)))
            db.add(Alert(farm_id=farm.id, kind="recommendation", title="Crop recommendation", message="Rice is suitable for your field based on current inputs."))
            db.add(Alert(farm_id=farm.id, kind="warning", title="Monitor soil moisture", message="Review irrigation if moisture falls below the field threshold."))
        db.commit()
    finally:
        db.close()


if __name__ == "__main__":
    seed()
