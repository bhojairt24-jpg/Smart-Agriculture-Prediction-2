from datetime import datetime, timezone
from sqlalchemy import (
    String, Integer, Float, Boolean, DateTime, ForeignKey, Text,
    CheckConstraint, Index, UniqueConstraint
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database.session import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"
    __table_args__ = (
        CheckConstraint("role IN ('farmer','expert','admin')", name="ck_users_role"),
        Index("ix_users_role", "role"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(500), nullable=False)
    role: Mapped[str] = mapped_column(String(30), default="farmer", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    farms: Mapped[list["Farm"]] = relationship(back_populates="owner", cascade="all, delete-orphan")


class Farm(Base):
    __tablename__ = "farms"
    __table_args__ = (
        UniqueConstraint("owner_id", "name", name="uq_farms_owner_name"),
        CheckConstraint("area_acres > 0", name="ck_farms_area_positive"),
        CheckConstraint("latitude >= -90 AND latitude <= 90", name="ck_farms_latitude"),
        CheckConstraint("longitude >= -180 AND longitude <= 180", name="ck_farms_longitude"),
        Index("ix_farms_owner_id", "owner_id"),
        Index("ix_farms_location", "latitude", "longitude"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    name: Mapped[str] = mapped_column(String(150), nullable=False)
    location: Mapped[str] = mapped_column(String(200), nullable=False)
    latitude: Mapped[float] = mapped_column(Float, nullable=False)
    longitude: Mapped[float] = mapped_column(Float, nullable=False)
    area_acres: Mapped[float] = mapped_column(Float, nullable=False)
    soil_type: Mapped[str] = mapped_column(String(80), default="Loamy", nullable=False)
    current_crop: Mapped[str] = mapped_column(String(80), default="Rice", nullable=False)
    season: Mapped[str] = mapped_column(String(50), default="Kharif", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    owner: Mapped[User] = relationship(back_populates="farms")
    fields: Mapped[list["Field"]] = relationship(back_populates="farm", cascade="all, delete-orphan")
    soil_tests: Mapped[list["SoilTest"]] = relationship(back_populates="farm", cascade="all, delete-orphan")
    soil_readings: Mapped[list["SoilReading"]] = relationship(back_populates="farm", cascade="all, delete-orphan")
    weather_records: Mapped[list["WeatherData"]] = relationship(back_populates="farm", cascade="all, delete-orphan")
    alerts: Mapped[list["Alert"]] = relationship(back_populates="farm", cascade="all, delete-orphan")


class Field(Base):
    __tablename__ = "fields"
    __table_args__ = (
        UniqueConstraint("farm_id", "name", name="uq_fields_farm_name"),
        CheckConstraint("area_acres > 0", name="ck_fields_area_positive"),
        Index("ix_fields_farm_id", "farm_id"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    farm_id: Mapped[int] = mapped_column(ForeignKey("farms.id", ondelete="CASCADE"), nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    area_acres: Mapped[float] = mapped_column(Float, nullable=False)
    crop: Mapped[str] = mapped_column(String(80), nullable=False)
    farm: Mapped[Farm] = relationship(back_populates="fields")


class SoilTest(Base):
    __tablename__ = "soil_tests"
    __table_args__ = (
        CheckConstraint("nitrogen >= 0 AND nitrogen <= 1000", name="ck_soil_nitrogen"),
        CheckConstraint("phosphorus >= 0 AND phosphorus <= 1000", name="ck_soil_phosphorus"),
        CheckConstraint("potassium >= 0 AND potassium <= 1000", name="ck_soil_potassium"),
        CheckConstraint("ph >= 0 AND ph <= 14", name="ck_soil_ph"),
        CheckConstraint("organic_carbon >= 0 AND organic_carbon <= 20", name="ck_soil_organic_carbon"),
        CheckConstraint("moisture >= 0 AND moisture <= 100", name="ck_soil_moisture"),
        CheckConstraint("source IN ('manual','ocr','uploaded_report','demo')", name="ck_soil_source"),
        Index("ix_soil_tests_farm_created", "farm_id", "created_at"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    farm_id: Mapped[int] = mapped_column(ForeignKey("farms.id", ondelete="CASCADE"), nullable=False)
    nitrogen: Mapped[float] = mapped_column(Float, nullable=False)
    phosphorus: Mapped[float] = mapped_column(Float, nullable=False)
    potassium: Mapped[float] = mapped_column(Float, nullable=False)
    ph: Mapped[float] = mapped_column(Float, nullable=False)
    organic_carbon: Mapped[float] = mapped_column(Float, nullable=False)
    moisture: Mapped[float] = mapped_column(Float, nullable=False)
    source: Mapped[str] = mapped_column(String(30), default="manual", nullable=False)
    verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    farm: Mapped[Farm] = relationship(back_populates="soil_tests")


class SoilReading(Base):
    __tablename__ = "soil_readings"
    __table_args__ = (Index("ix_soil_readings_farm_recorded", "farm_id", "recorded_at"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    farm_id: Mapped[int] = mapped_column(ForeignKey("farms.id", ondelete="CASCADE"), nullable=False)
    moisture: Mapped[float] = mapped_column(Float, nullable=False)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    farm: Mapped[Farm] = relationship(back_populates="soil_readings")


class WeatherData(Base):
    __tablename__ = "weather_data"
    __table_args__ = (Index("ix_weather_farm_recorded", "farm_id", "recorded_at"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    farm_id: Mapped[int] = mapped_column(ForeignKey("farms.id", ondelete="CASCADE"), nullable=False)
    temperature: Mapped[float] = mapped_column(Float, nullable=False)
    humidity: Mapped[float] = mapped_column(Float, nullable=False)
    wind_kmh: Mapped[float] = mapped_column(Float, nullable=False)
    rainfall_mm: Mapped[float] = mapped_column(Float, nullable=False)
    rain_probability: Mapped[float] = mapped_column(Float, nullable=False)
    condition: Mapped[str] = mapped_column(String(80), nullable=False)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    farm: Mapped[Farm] = relationship(back_populates="weather_records")


class CropPrediction(Base):
    __tablename__ = "crop_predictions"
    __table_args__ = (Index("ix_crop_predictions_farm_created", "farm_id", "created_at"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    farm_id: Mapped[int] = mapped_column(ForeignKey("farms.id", ondelete="CASCADE"), nullable=False)
    recommended_crop: Mapped[str] = mapped_column(String(80), nullable=False)
    confidence: Mapped[float] = mapped_column(Float, nullable=False)
    alternatives_json: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


class YieldPrediction(Base):
    __tablename__ = "yield_predictions"
    __table_args__ = (
        CheckConstraint("yield_tph >= 0", name="ck_yield_nonnegative"),
        CheckConstraint("total_production_tonnes >= 0", name="ck_production_nonnegative"),
        Index("ix_yield_predictions_farm_created", "farm_id", "created_at"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    farm_id: Mapped[int] = mapped_column(ForeignKey("farms.id", ondelete="CASCADE"), nullable=False)
    crop: Mapped[str] = mapped_column(String(80), nullable=False)
    yield_tph: Mapped[float] = mapped_column(Float, nullable=False)
    total_production_tonnes: Mapped[float] = mapped_column(Float, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


class IrrigationPrediction(Base):
    __tablename__ = "irrigation_predictions"
    __table_args__ = (Index("ix_irrigation_farm_created", "farm_id", "created_at"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    farm_id: Mapped[int] = mapped_column(ForeignKey("farms.id", ondelete="CASCADE"), nullable=False)
    required: Mapped[bool] = mapped_column(Boolean, nullable=False)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    action: Mapped[str] = mapped_column(Text, nullable=False)
    water_liters: Mapped[float | None] = mapped_column(Float, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


class DiseaseScan(Base):
    __tablename__ = "disease_scans"
    __table_args__ = (Index("ix_disease_farm_created", "farm_id", "created_at"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    farm_id: Mapped[int | None] = mapped_column(ForeignKey("farms.id", ondelete="SET NULL"), nullable=True)
    filename: Mapped[str] = mapped_column(String(255), nullable=False)
    disease: Mapped[str] = mapped_column(String(150), nullable=False)
    confidence: Mapped[float] = mapped_column(Float, nullable=False)
    severity: Mapped[str] = mapped_column(String(50), nullable=False)
    guidance: Mapped[str] = mapped_column(Text, nullable=False)
    demo_mode: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


class Alert(Base):
    __tablename__ = "alerts"
    __table_args__ = (Index("ix_alerts_farm_read_created", "farm_id", "is_read", "created_at"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    farm_id: Mapped[int] = mapped_column(ForeignKey("farms.id", ondelete="CASCADE"), nullable=False)
    kind: Mapped[str] = mapped_column(String(30), nullable=False)
    title: Mapped[str] = mapped_column(String(180), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    is_read: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    farm: Mapped[Farm] = relationship(back_populates="alerts")


class Report(Base):
    __tablename__ = "reports"
    __table_args__ = (Index("ix_reports_farm_created", "farm_id", "created_at"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    farm_id: Mapped[int] = mapped_column(ForeignKey("farms.id", ondelete="CASCADE"), nullable=False)
    filename: Mapped[str] = mapped_column(String(255), nullable=False)
    path: Mapped[str] = mapped_column(String(500), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


class ChatHistory(Base):
    __tablename__ = "chat_history"
    __table_args__ = (Index("ix_chat_history_user_created", "user_id", "created_at"), Index("ix_chat_history_farm_created", "farm_id", "created_at"))
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    farm_id: Mapped[int | None] = mapped_column(ForeignKey("farms.id", ondelete="SET NULL"), nullable=True)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    response: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    __table_args__ = (
        Index("ix_audit_logs_table_record", "table_name", "record_id"),
        Index("ix_audit_logs_created", "created_at"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    table_name: Mapped[str] = mapped_column(String(100), nullable=False)
    record_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    action: Mapped[str] = mapped_column(String(20), nullable=False)
    old_data: Mapped[str | None] = mapped_column(Text, nullable=True)
    new_data: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
