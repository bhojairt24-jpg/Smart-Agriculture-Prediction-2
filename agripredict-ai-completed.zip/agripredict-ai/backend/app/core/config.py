from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "AgriPredict AI"
    environment: str = "development"
    demo_mode: bool = True
    database_url: str = "postgresql+psycopg://agripredict:agripredict@localhost:5432/agripredict"
    jwt_secret: str = "change-me"
    jwt_expire_minutes: int = 120
    frontend_origin: str = "http://localhost:5173"
    max_upload_mb: int = 8
    upload_dir: str = "uploads"
    report_dir: str = "reports"
    weather_provider: str = "open_meteo"
    weather_api_key: str | None = None
    llm_provider: str = "none"
    llm_api_key: str | None = None
    openai_base_url: str = "https://api.openai.com/v1"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

settings = Settings()
