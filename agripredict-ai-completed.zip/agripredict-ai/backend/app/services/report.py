from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from app.core.config import settings

def build_report(path, user, farm, soil, weather, crop, yield_pred, irrigation, disease, alerts):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    doc=SimpleDocTemplate(path,pagesize=A4,rightMargin=36,leftMargin=36,topMargin=36,bottomMargin=36)
    styles=getSampleStyleSheet(); story=[Paragraph("AgriPredict AI – Farm Intelligence Report",styles["Title"]),Spacer(1,10),Paragraph(f"Farmer: {user.name} | Farm: {farm.name}",styles["Heading2"]),Paragraph(f"Location: {farm.location} | Area: {farm.area_acres} acres | Crop: {farm.current_crop}",styles["BodyText"]),Spacer(1,12)]
    rows=[["Metric","Value"],["N (kg/ha)",soil.get("nitrogen","—")],["P (kg/ha)",soil.get("phosphorus","—")],["K (kg/ha)",soil.get("potassium","—")],["pH",soil.get("ph","—")],["Moisture (%)",soil.get("moisture","—")],["Temperature (°C)",weather.get("temperature","—")],["Humidity (%)",weather.get("humidity","—")]]
    t=Table(rows,colWidths=[180,180]); t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#e8f5ee")),("GRID",(0,0),(-1,-1),0.4,colors.grey),("PADDING",(0,0),(-1,-1),6)])); story += [Paragraph("Soil & Weather",styles["Heading2"]),t,Spacer(1,12)]
    story += [Paragraph("Crop Recommendation",styles["Heading2"]),Paragraph(f"Recommended crop: {crop.get('recommended_crop','—')}",styles["BodyText"]),Paragraph(f"Alternatives: {crop.get('alternatives','—')}",styles["BodyText"]),Spacer(1,8),Paragraph("Yield Prediction",styles["Heading2"]),Paragraph(f"Estimated yield: {yield_pred.get('yield_tph','—')} tonnes/hectare; total production: {yield_pred.get('total_production_tonnes','—')} tonnes.",styles["BodyText"]),Spacer(1,8),Paragraph("Irrigation Advisor",styles["Heading2"]),Paragraph(irrigation.get("action","—"),styles["BodyText"]),Spacer(1,8)]
    if disease: story += [Paragraph("Disease Detection",styles["Heading2"]),Paragraph(f"{disease.get('disease')} ({disease.get('severity')}) – {disease.get('guidance')}",styles["BodyText"])]
    story += [Spacer(1,10),Paragraph("Alerts",styles["Heading2"])] + [Paragraph(f"• {a.title}: {a.message}",styles["BodyText"]) for a in alerts]
    doc.build(story)
