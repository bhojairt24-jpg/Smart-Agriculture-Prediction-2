from datetime import datetime
import httpx
from app.core.config import settings

def demo_weather(lat=18.52, lon=73.85):
    return {"temperature":29,"humidity":72,"wind_kmh":12,"rainfall_mm":2,"rain_probability":10,"condition":"Partly Cloudy","forecast":[{"day":"Mon","temp":29,"rain":10},{"day":"Tue","temp":27,"rain":60},{"day":"Wed","temp":26,"rain":65},{"day":"Thu","temp":30,"rain":20},{"day":"Fri","temp":31,"rain":10},{"day":"Sat","temp":28,"rain":45},{"day":"Sun","temp":29,"rain":25}],"source":"demo"}

def get_weather(lat: float, lon: float):
    if settings.demo_mode and settings.weather_provider == "demo": return demo_weather(lat,lon)
    try:
        if settings.weather_provider.lower() == "weatherapi":
            if not settings.weather_api_key: raise RuntimeError("WeatherAPI key missing")
            url="https://api.weatherapi.com/v1/forecast.json"
            params={"key":settings.weather_api_key,"q":f"{lat},{lon}","days":7,"aqi":"no","alerts":"no"}
            data=httpx.get(url,params=params,timeout=8).raise_for_status()
            j=data.json(); cur=j["current"]; fc=[]
            for d in j["forecast"]["forecastday"]:
                fc.append({"day":datetime.fromisoformat(d["date"]).strftime("%a"),"temp":round(d["day"]["avgtemp_c"]),"rain":d["day"]["daily_chance_of_rain"]})
            return {"temperature":round(cur["temp_c"]),"humidity":cur["humidity"],"wind_kmh":round(cur["wind_kph"]),"rainfall_mm":cur.get("precip_mm",0),"rain_probability":fc[0]["rain"],"condition":cur["condition"]["text"],"forecast":fc,"source":"weatherapi"}
        # Open-Meteo: no API key required.
        url="https://api.open-meteo.com/v1/forecast"
        params={"latitude":lat,"longitude":lon,"current":"temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,weather_code","daily":"temperature_2m_max,precipitation_probability_max","forecast_days":7,"timezone":"auto"}
        j=httpx.get(url,params=params,timeout=8).raise_for_status().json()
        code=j["current"]["weather_code"]
        condition={0:"Clear",1:"Mainly Clear",2:"Partly Cloudy",3:"Overcast",61:"Rain",63:"Rain",65:"Heavy Rain"}.get(code,"Weather")
        fc=[{"day":datetime.fromisoformat(d).strftime("%a"),"temp":round(t),"rain":p or 0} for d,t,p in zip(j["daily"]["time"],j["daily"]["temperature_2m_max"],j["daily"]["precipitation_probability_max"])]
        return {"temperature":round(j["current"]["temperature_2m"]),"humidity":j["current"]["relative_humidity_2m"],"wind_kmh":round(j["current"]["wind_speed_10m"]),"rainfall_mm":j["current"]["precipitation"],"rain_probability":fc[0]["rain"],"condition":condition,"forecast":fc,"source":"open-meteo"}
    except Exception:
        if settings.demo_mode: return demo_weather(lat,lon)
        raise
