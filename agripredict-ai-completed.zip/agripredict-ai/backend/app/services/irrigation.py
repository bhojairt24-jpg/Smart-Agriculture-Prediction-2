def recommend_irrigation(soil_moisture, temperature, humidity, crop, growth_stage, rain_probability, expected_rainfall, area_acres=5):
    adequate = soil_moisture >= 35
    likely_rain = rain_probability >= 60 or expected_rainfall >= 8
    if adequate and likely_rain:
        return {"required": False, "reason": "Rain probability is high and current soil moisture is adequate.", "action": "Delay irrigation for approximately 18–24 hours and reassess soil moisture.", "water_liters": 0}
    if soil_moisture < 25:
        liters = round(area_acres * 4046.86 * 0.02, 0)
        return {"required": True, "reason": "Current soil moisture is low for the selected crop context.", "action": "Irrigate promptly, then recheck moisture before the next cycle.", "water_liters": liters}
    if temperature >= 34 and humidity < 45 and rain_probability < 40:
        liters = round(area_acres * 4046.86 * 0.01, 0)
        return {"required": True, "reason": "High temperature and lower humidity increase short-term water demand.", "action": "Consider a measured irrigation cycle and monitor evapotranspiration conditions.", "water_liters": liters}
    return {"required": False, "reason": "Current moisture and weather signals do not indicate an immediate irrigation need.", "action": "Continue monitoring and reassess within 12–24 hours.", "water_liters": 0}
