import io
import re
from pathlib import Path
from PIL import Image
from app.core.config import settings

DEMO_VALUES = {"nitrogen": 82.0, "phosphorus": 35.0, "potassium": 48.0, "ph": 6.7, "organic_carbon": 0.72, "moisture": 42.0}


def extract_soil_values(filename: str, data: bytes):
    text = ""
    suffix = Path(filename).suffix.lower()
    try:
        if suffix == ".pdf":
            from pypdf import PdfReader
            reader = PdfReader(io.BytesIO(data))
            text = "\n".join(page.extract_text() or "" for page in reader.pages)
        else:
            import pytesseract
            text = pytesseract.image_to_string(Image.open(io.BytesIO(data)))
    except Exception:
        text = ""

    def find(pattern):
        m = re.search(pattern, text, re.I)
        return float(m.group(1)) if m else None

    if text.strip():
        vals = {
            "nitrogen": find(r"(?:N|Nitrogen)\s*[:=\-]?\s*(\d+(?:\.\d+)?)"),
            "phosphorus": find(r"(?:P|Phosphorus)\s*[:=\-]?\s*(\d+(?:\.\d+)?)"),
            "potassium": find(r"(?:K|Potassium)\s*[:=\-]?\s*(\d+(?:\.\d+)?)"),
            "ph": find(r"pH\s*[:=\-]?\s*(\d+(?:\.\d+)?)"),
            "organic_carbon": find(r"(?:Organic Carbon|OC)\s*[:=\-]?\s*(\d+(?:\.\d+)?)"),
            "moisture": find(r"(?:Moisture|Soil Moisture)\s*[:=\-]?\s*(\d+(?:\.\d+)?)"),
        }
        # OCR can miss one label; use the demo value only for missing fields while still marking the record as OCR-derived.
        vals = {k: (v if v is not None else DEMO_VALUES[k]) for k, v in vals.items()}
        return vals, True, False

    if settings.demo_mode:
        return DEMO_VALUES.copy(), False, True
    return {}, False, False
