from pathlib import Path
from uuid import uuid4
from fastapi import APIRouter, Depends, File, UploadFile, HTTPException
from PIL import Image
import io
from sqlalchemy.orm import Session
from app.core.config import settings
from app.database.session import get_db
from app.models import SoilTest, SoilReading
from app.schemas import SoilInput
from app.api.deps import get_current_user, get_owned_farm
from app.services.ocr import extract_soil_values

router = APIRouter(prefix="/api/soil", tags=["Soil"])
ALLOWED = {".pdf", ".jpg", ".jpeg", ".png"}

@router.post("/upload")
async def upload(farm_id: int, file: UploadFile = File(...), user=Depends(get_current_user), db: Session = Depends(get_db)):
    get_owned_farm(farm_id, user, db)
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED:
        raise HTTPException(415, "Only PDF, JPG, JPEG and PNG files are accepted")
    data = await file.read()
    if len(data) > settings.max_upload_mb * 1024 * 1024:
        raise HTTPException(413, "File is too large")
    if ext == ".pdf":
        if not data.lstrip().startswith(b"%PDF"):
            raise HTTPException(415, "The uploaded file is not a valid PDF")
    else:
        try:
            with Image.open(io.BytesIO(data)) as image:
                image.verify()
        except Exception as exc:
            raise HTTPException(415, "The uploaded file is not a valid image") from exc
    upload_dir = Path(settings.upload_dir)
    upload_dir.mkdir(parents=True, exist_ok=True)
    stored = upload_dir / f"{uuid4().hex}{ext}"
    stored.write_bytes(data)
    vals, ocr_used, demo_used = extract_soil_values(file.filename or stored.name, data)
    if not vals:
        raise HTTPException(status_code=503, detail="OCR is unavailable. Enter soil values manually or enable DEMO_MODE.")
    source = "ocr" if ocr_used else ("demo" if demo_used else "uploaded_report")
    message = "OCR values extracted. Please verify or correct them before saving." if ocr_used else "Demo extraction values shown because OCR is unavailable. Please verify or replace them before saving."
    return {"values": vals, "verified": False, "source": source, "ocr_used": ocr_used, "demo_used": demo_used, "filename": file.filename, "message": message}

@router.post("/analyze")
def analyze(data: SoilInput, user=Depends(get_current_user), db: Session = Depends(get_db)):
    farm = get_owned_farm(data.farm_id, user, db)
    values = data.model_dump()
    values.pop("farm_id")
    source = values.pop("source")
    s = SoilTest(farm_id=farm.id, source=source, **values)
    db.add(s)
    db.add(SoilReading(farm_id=farm.id, moisture=data.moisture))
    db.commit()
    db.refresh(s)
    health = round(max(0, min(100, 60 + min(data.moisture, 60) * 0.25 + (10 if 5.5 <= data.ph <= 7.5 else -10) + min(data.organic_carbon, 3) * 3)))
    return {"id": s.id, "farm_id": farm.id, "values": {**data.model_dump(), "source": source}, "soil_health_score": health, "status": "Good" if health >= 75 else "Needs attention"}

@router.get("/{farm_id}")
def history(farm_id: int, user=Depends(get_current_user), db: Session = Depends(get_db)):
    get_owned_farm(farm_id, user, db)
    rows = db.query(SoilTest).filter(SoilTest.farm_id == farm_id).order_by(SoilTest.created_at.desc()).limit(20).all()
    return [{"id": r.id, "nitrogen": r.nitrogen, "phosphorus": r.phosphorus, "potassium": r.potassium, "ph": r.ph, "organic_carbon": r.organic_carbon, "moisture": r.moisture, "verified": r.verified, "source": r.source, "created_at": r.created_at} for r in rows]
