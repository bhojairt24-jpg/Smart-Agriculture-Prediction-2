from fastapi import APIRouter,Depends
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.models import Farm,SoilTest,ChatHistory
from app.schemas import AssistantInput
from app.api.deps import get_current_user,get_owned_farm
router=APIRouter(prefix="/api/assistant",tags=["Assistant"])
def fallback(msg,farm,soil):
    m=msg.lower(); moisture=soil.moisture if soil else 42
    if "irrig" in m: return f"Your current soil moisture is about {moisture:.0f}%. The platform recommends using soil moisture together with rainfall probability before irrigating. This assistant explains the validated irrigation result; it does not create a new measurement."
    if "crop" in m: return "The crop recommendation model uses nitrogen, phosphorus, potassium, temperature, humidity, pH and rainfall. It is a decision-support estimate based on its training data."
    if "disease" in m: return "Disease analysis is image-based. Treat the result as a screening aid and confirm important cases with a qualified agricultural expert."
    return f"For {farm.name if farm else 'your farm'}, I can explain soil, crop, yield, irrigation, disease and weather results. Ask a specific question and I will use the stored farm context."
@router.post("/chat")
def chat(data:AssistantInput,user=Depends(get_current_user),db:Session=Depends(get_db)):
    farm=get_owned_farm(data.farm_id,user,db) if data.farm_id else None; soil=db.query(SoilTest).filter_by(farm_id=farm.id).order_by(SoilTest.created_at.desc()).first() if farm else None
    response=fallback(data.message,farm,soil); db.add(ChatHistory(user_id=user.id,farm_id=farm.id if farm else None,message=data.message,response=response)); db.commit(); return {"response":response,"provider":"fallback"}
