from fastapi import APIRouter,Depends
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.models import WeatherData
from app.api.deps import get_current_user,get_owned_farm
from app.services.weather import get_weather
router=APIRouter(prefix="/api/weather",tags=["Weather"])
@router.get("/{farm_id}")
def weather(farm_id:int,user=Depends(get_current_user),db:Session=Depends(get_db)):
    f=get_owned_farm(farm_id,user,db); out=get_weather(f.latitude,f.longitude); db.add(WeatherData(farm_id=f.id,temperature=out["temperature"],humidity=out["humidity"],wind_kmh=out["wind_kmh"],rainfall_mm=out["rainfall_mm"],rain_probability=out["rain_probability"],condition=out["condition"])); db.commit(); return out
