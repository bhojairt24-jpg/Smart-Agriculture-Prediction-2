from fastapi import APIRouter, Depends
from sqlalchemy import text, func
from sqlalchemy.orm import Session
from app.api.deps import require_roles
from app.database.session import get_db
from app.models import User, Farm, CropPrediction, YieldPrediction, Alert, AuditLog

router = APIRouter(prefix="/api/admin", tags=["Admin"])

@router.get("/overview")
def overview(user=Depends(require_roles("admin")), db: Session = Depends(get_db)):
    if db.bind and db.bind.dialect.name == "postgresql":
        farm_rows = db.execute(text("SELECT farm_id, owner_id, name, location, area_acres, current_crop, season, field_count, crop_prediction_count, yield_prediction_count, unread_alert_count FROM farm_summary ORDER BY farm_id")).mappings().all()
        soil_rows = db.execute(text("SELECT farm_id, nitrogen, phosphorus, potassium, ph, organic_carbon, moisture, source, verified, soil_status FROM latest_soil_status ORDER BY farm_id")).mappings().all()
    else:
        farm_rows = db.query(Farm).order_by(Farm.id).all()
        soil_rows = []
    return {
        "admin": {"id": user.id, "name": user.name},
        "totals": {
            "users": db.query(func.count(User.id)).scalar(),
            "farms": db.query(func.count(Farm.id)).scalar(),
            "crop_predictions": db.query(func.count(CropPrediction.id)).scalar(),
            "yield_predictions": db.query(func.count(YieldPrediction.id)).scalar(),
            "unread_alerts": db.query(func.count(Alert.id)).filter(Alert.is_read.is_(False)).scalar(),
            "audit_events": db.query(func.count(AuditLog.id)).scalar(),
        },
        "farm_summary": [dict(r) if hasattr(r, "keys") else {"farm_id": r.id, "name": r.name, "owner_id": r.owner_id} for r in farm_rows],
        "latest_soil": [dict(r) for r in soil_rows],
    }
