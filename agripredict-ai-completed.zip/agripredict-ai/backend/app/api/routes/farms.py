from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from app.database.session import get_db
from app.models import Farm, Field
from app.schemas import FarmCreate, FarmUpdate, FarmOut, FieldCreate, FieldOut
from app.api.deps import get_current_user, get_owned_farm

router = APIRouter(prefix="/api/farms", tags=["Farms"])

@router.get("", response_model=list[FarmOut])
def list_farms(user=Depends(get_current_user), db: Session = Depends(get_db)):
    q = db.query(Farm)
    if user.role != "admin":
        q = q.filter(Farm.owner_id == user.id)
    return q.order_by(Farm.id).all()

@router.post("", response_model=FarmOut, status_code=201)
def create(data: FarmCreate, user=Depends(get_current_user), db: Session = Depends(get_db)):
    f = Farm(owner_id=user.id, **data.model_dump())
    db.add(f)
    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(409, "A farm with this name already exists for this account") from exc
    db.refresh(f)
    return f

@router.get("/{farm_id}", response_model=FarmOut)
def get(farm_id: int, user=Depends(get_current_user), db: Session = Depends(get_db)):
    return get_owned_farm(farm_id, user, db)

@router.put("/{farm_id}", response_model=FarmOut)
def update(farm_id: int, data: FarmUpdate, user=Depends(get_current_user), db: Session = Depends(get_db)):
    f = get_owned_farm(farm_id, user, db)
    for k, v in data.model_dump().items():
        setattr(f, k, v)
    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(409, "A farm with this name already exists for this account") from exc
    db.refresh(f)
    return f

@router.delete("/{farm_id}")
def delete(farm_id: int, user=Depends(get_current_user), db: Session = Depends(get_db)):
    f = get_owned_farm(farm_id, user, db)
    db.delete(f)
    db.commit()
    return {"message": "Farm deleted"}

@router.get("/{farm_id}/fields", response_model=list[FieldOut])
def list_fields(farm_id: int, user=Depends(get_current_user), db: Session = Depends(get_db)):
    get_owned_farm(farm_id, user, db)
    return db.query(Field).filter(Field.farm_id == farm_id).order_by(Field.id).all()

@router.post("/{farm_id}/fields", response_model=FieldOut, status_code=201)
def add_field(farm_id: int, data: FieldCreate, user=Depends(get_current_user), db: Session = Depends(get_db)):
    f = get_owned_farm(farm_id, user, db)
    x = Field(farm_id=f.id, **data.model_dump())
    db.add(x)
    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(409, "A field with this name already exists in this farm") from exc
    db.refresh(x)
    return x
