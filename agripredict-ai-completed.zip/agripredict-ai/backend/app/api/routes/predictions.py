import json
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import text
from app.database.session import get_db
from app.models import CropPrediction,YieldPrediction,IrrigationPrediction,Alert
from app.schemas import CropInput,YieldInput,IrrigationInput
from app.api.deps import get_current_user,get_owned_farm
from app.ml.crop_service import predict as crop_predict
from app.ml.yield_service import predict as yield_predict
from app.services.irrigation import recommend_irrigation
router=APIRouter(prefix="/api/predictions",tags=["Predictions"])
@router.post("/crop")
def crop(data:CropInput,user=Depends(get_current_user),db:Session=Depends(get_db)):
    farm=get_owned_farm(data.farm_id,user,db); out=crop_predict(data.model_dump()); row=CropPrediction(farm_id=farm.id,recommended_crop=out["recommended_crop"],confidence=out.get("confidence") or 0,alternatives_json=json.dumps(out["alternatives"])); db.add(row); db.add(Alert(farm_id=farm.id,kind="recommendation",title="New crop prediction available",message=f"{out['recommended_crop']} is the current model recommendation.")); db.commit(); return out
@router.post("/yield")
def yield_(data:YieldInput,user=Depends(get_current_user),db:Session=Depends(get_db)):
    farm=get_owned_farm(data.farm_id,user,db); out=yield_predict(data.model_dump())
    if db.bind and db.bind.dialect.name == "postgresql":
        db.execute(text("CALL sp_finalize_yield_prediction(:farm_id, :crop, :yield_tph, :total_production_tonnes)"), {"farm_id": farm.id, "crop": data.crop, "yield_tph": out["yield_tph"], "total_production_tonnes": out["total_production_tonnes"]})
    else:
        db.add(YieldPrediction(farm_id=farm.id,crop=data.crop,yield_tph=out["yield_tph"],total_production_tonnes=out["total_production_tonnes"]))
    db.commit(); return out
@router.post("/irrigation")
def irrigation(data:IrrigationInput,user=Depends(get_current_user),db:Session=Depends(get_db)):
    farm=get_owned_farm(data.farm_id,user,db); out=recommend_irrigation(**{k:v for k,v in data.model_dump().items() if k!="farm_id"},area_acres=farm.area_acres); row=IrrigationPrediction(farm_id=farm.id,**out); db.add(row); db.commit(); return out
