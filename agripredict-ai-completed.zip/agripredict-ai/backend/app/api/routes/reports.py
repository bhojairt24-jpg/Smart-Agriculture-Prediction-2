from pathlib import Path
from uuid import uuid4
from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy.orm import Session
from fastapi.responses import FileResponse
from app.database.session import get_db
from app.core.config import settings
from app.models import Farm,SoilTest,WeatherData,CropPrediction,YieldPrediction,IrrigationPrediction,DiseaseScan,Alert,Report
from app.schemas import ReportInput
from app.api.deps import get_current_user,get_owned_farm
from app.services.report import build_report
router=APIRouter(prefix="/api/reports",tags=["Reports"])
@router.post("/generate")
def generate(data:ReportInput,user=Depends(get_current_user),db:Session=Depends(get_db)):
    f=get_owned_farm(data.farm_id,user,db); soil=db.query(SoilTest).filter_by(farm_id=f.id).order_by(SoilTest.created_at.desc()).first(); weather=db.query(WeatherData).filter_by(farm_id=f.id).order_by(WeatherData.recorded_at.desc()).first(); crop=db.query(CropPrediction).filter_by(farm_id=f.id).order_by(CropPrediction.created_at.desc()).first(); yp=db.query(YieldPrediction).filter_by(farm_id=f.id).order_by(YieldPrediction.created_at.desc()).first(); ip=db.query(IrrigationPrediction).filter_by(farm_id=f.id).order_by(IrrigationPrediction.created_at.desc()).first(); ds=db.query(DiseaseScan).filter_by(farm_id=f.id).order_by(DiseaseScan.created_at.desc()).first(); alerts=db.query(Alert).filter_by(farm_id=f.id).order_by(Alert.created_at.desc()).limit(10).all()
    path=Path(settings.report_dir)/(f"farm_{f.id}_{uuid4().hex[:8]}.pdf"); build_report(str(path),user,f,soil.__dict__ if soil else {},weather.__dict__ if weather else {},{"recommended_crop":crop.recommended_crop if crop else f.current_crop,"alternatives":crop.alternatives_json if crop else "—"},{"yield_tph":yp.yield_tph if yp else "—","total_production_tonnes":yp.total_production_tonnes if yp else "—"},{"action":ip.action if ip else "No irrigation assessment yet."},{"disease":ds.disease,"severity":ds.severity,"guidance":ds.guidance} if ds else None,alerts); r=Report(farm_id=f.id,filename=path.name,path=str(path)); db.add(r); db.commit(); return {"report_id":r.id,"filename":path.name,"download_url":f"/api/reports/{r.id}/download"}
@router.get("/{report_id}/download")
def download(report_id:int,user=Depends(get_current_user),db:Session=Depends(get_db)):
    r=db.get(Report,report_id)
    if not r: raise HTTPException(status_code=404, detail="Report not found")
    f=db.get(Farm,r.farm_id)
    if f.owner_id!=user.id and user.role != "admin": raise HTTPException(status_code=403, detail="Not authorized for this report")
    return FileResponse(r.path,media_type="application/pdf",filename=r.filename)
