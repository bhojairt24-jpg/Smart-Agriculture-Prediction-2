from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.models import Alert,Farm
from app.api.deps import get_current_user, get_owned_farm
router=APIRouter(prefix="/api/alerts",tags=["Alerts"])
@router.get("")
def alerts(user=Depends(get_current_user),db:Session=Depends(get_db)):
    ids=[x.id for x in db.query(Farm.id).filter(Farm.owner_id==user.id).all()] if user.role != "admin" else [x.id for x in db.query(Farm.id).all()]; rows=db.query(Alert).filter(Alert.farm_id.in_(ids)).order_by(Alert.created_at.desc()).limit(50).all(); return [{"id":a.id,"farm_id":a.farm_id,"kind":a.kind,"title":a.title,"message":a.message,"is_read":a.is_read,"created_at":a.created_at} for a in rows]
@router.put("/{alert_id}/read")
def read(alert_id:int,user=Depends(get_current_user),db:Session=Depends(get_db)):
    a=db.get(Alert,alert_id)
    if not a: raise HTTPException(status_code=404, detail="Alert not found")
    farm=db.get(Farm,a.farm_id)
    if farm.owner_id!=user.id and user.role != "admin": raise HTTPException(status_code=403, detail="Not authorized for this alert")
    a.is_read=True; db.commit(); return {"message":"Marked as read"}
