from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.models import Farm, SoilTest, WeatherData, CropPrediction, YieldPrediction, Alert, SoilReading
from app.api.deps import get_current_user, get_owned_farm
from app.services.weather import get_weather
from app.ml.crop_service import predict as crop_predict

router = APIRouter(prefix="/api", tags=["Dashboard"])

@router.get("/dashboard/{farm_id}")
def dashboard(farm_id: int, user=Depends(get_current_user), db: Session = Depends(get_db)):
    f = get_owned_farm(farm_id, user, db)
    s = db.query(SoilTest).filter_by(farm_id=f.id).order_by(SoilTest.created_at.desc()).first()
    w = db.query(WeatherData).filter_by(farm_id=f.id).order_by(WeatherData.recorded_at.desc()).first()
    if not w:
        wd = get_weather(f.latitude, f.longitude)
        w = WeatherData(farm_id=f.id, temperature=wd["temperature"], humidity=wd["humidity"], wind_kmh=wd["wind_kmh"], rainfall_mm=wd["rainfall_mm"], rain_probability=wd["rain_probability"], condition=wd["condition"])
        db.add(w)
        db.commit()
        db.refresh(w)
        forecast = wd["forecast"]
    else:
        wd = get_weather(f.latitude, f.longitude)
        forecast = wd["forecast"]
    temp, hum, rain, rp, cond = w.temperature, w.humidity, w.rainfall_mm, w.rain_probability, w.condition
    moisture = s.moisture if s else 42
    ph = s.ph if s else 6.7
    health = round(max(0, min(100, 70 + (moisture - 40) * .25 + (8 if 5.5 <= ph <= 7.5 else -8) - (8 if hum > 85 else 0))))
    readings = db.query(SoilReading).filter_by(farm_id=f.id).order_by(SoilReading.recorded_at).limit(30).all()
    crop = crop_predict({"nitrogen": s.nitrogen if s else 82, "phosphorus": s.phosphorus if s else 35, "potassium": s.potassium if s else 48, "temperature": temp, "humidity": hum, "ph": ph, "rainfall": rain + 20})
    alerts = db.query(Alert).filter_by(farm_id=f.id).order_by(Alert.created_at.desc()).limit(5).all()
    return {"farm": {"id": f.id, "name": f.name, "location": f.location, "area_acres": f.area_acres, "crop": f.current_crop}, "stats": {"temperature": temp, "soil_moisture": moisture, "rainfall": rain, "rain_probability": rp, "farm_health": health, "condition": cond}, "soil_history": [{"date": r.recorded_at.strftime('%a'), "moisture": r.moisture} for r in readings], "weather_forecast": forecast, "insights": [f"{crop['recommended_crop']} is suitable for your field based on current inputs.", "Irrigation can be delayed when rainfall probability is high and moisture remains adequate.", "Use the yield page for a model estimate based on current farm conditions.", "Monitor crops regularly for disease symptoms."], "alerts": [{"id": a.id, "kind": a.kind, "title": a.title, "message": a.message, "is_read": a.is_read} for a in alerts]}

@router.get("/analytics/{farm_id}")
def analytics(farm_id: int, user=Depends(get_current_user), db: Session = Depends(get_db)):
    get_owned_farm(farm_id, user, db)
    readings = db.query(SoilReading).filter_by(farm_id=farm_id).order_by(SoilReading.recorded_at).limit(30).all()
    ys = db.query(YieldPrediction).filter_by(farm_id=farm_id).order_by(YieldPrediction.created_at).all()
    weather = db.query(WeatherData).filter_by(farm_id=farm_id).order_by(WeatherData.recorded_at).limit(30).all()
    return {"soil_moisture": [{"date": r.recorded_at.strftime('%d %b'), "value": r.moisture} for r in readings], "yield_history": [{"date": y.created_at.strftime('%d %b'), "value": y.yield_tph, "crop": y.crop} for y in ys], "temperature_history": [{"date": w.recorded_at.strftime('%d %b'), "value": w.temperature} for w in weather], "rainfall_history": [{"date": w.recorded_at.strftime('%d %b'), "value": w.rainfall_mm} for w in weather]}
