from pathlib import Path
from uuid import uuid4
from fastapi import APIRouter, Depends, File, UploadFile, HTTPException
from PIL import Image
import io
from sqlalchemy.orm import Session
from app.core.config import settings
from app.database.session import get_db
from app.models import DiseaseScan
from app.api.deps import get_current_user,get_owned_farm
from app.ml.disease_service import analyze
router=APIRouter(prefix="/api/disease",tags=["Disease"])
@router.post("/analyze")
async def disease(farm_id:int,file:UploadFile=File(...),user=Depends(get_current_user),db:Session=Depends(get_db)):
    get_owned_farm(farm_id,user,db); ext=Path(file.filename or "").suffix.lower()
    if ext not in {".jpg",".jpeg",".png"}: raise HTTPException(415,"Only JPG, JPEG and PNG files are accepted")
    data=await file.read()
    if len(data)>settings.max_upload_mb*1024*1024: raise HTTPException(413,"Image is too large")
    try:
        with Image.open(io.BytesIO(data)) as image:
            image.verify()
    except Exception as exc:
        raise HTTPException(415,"The uploaded file is not a valid image") from exc
    path=Path("uploads")/(f"{uuid4().hex}{ext}"); path.parent.mkdir(exist_ok=True); path.write_bytes(data)
    try: out=analyze(path)
    except Exception as exc: raise HTTPException(503,"Disease model is unavailable. Enable DEMO_MODE or install a trained model.") from exc
    row=DiseaseScan(farm_id=farm_id,filename=file.filename or path.name,disease=out["disease"],confidence=out["confidence"],severity=out["severity"],guidance=out["guidance"],demo_mode=out["demo_mode"]); db.add(row); db.commit(); return out
