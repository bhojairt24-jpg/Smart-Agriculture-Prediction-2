# Database migrations

Alembic migrations live in `backend/alembic/`. Run `cd backend && alembic upgrade head`.
