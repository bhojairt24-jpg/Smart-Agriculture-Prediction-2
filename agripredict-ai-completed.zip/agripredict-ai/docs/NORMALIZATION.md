# Normalization

## 1NF
Every table stores atomic attributes. NPK values, pH, moisture, weather measurements, prediction outputs, and identity fields are individual columns rather than repeating groups.

## 2NF
Tables use a single surrogate primary key, and non-key attributes depend on that row. Farm-specific observations reference `farm_id`; they are not repeated in every prediction/reading row as farm location or owner details.

## 3NF
Transitive dependencies are separated. User identity/role belongs to `users`, farm ownership belongs to `farms`, and field data belongs to `fields`. A field row does not duplicate the owner's email or farm location. Weather and soil measurements are separate relations because they have different temporal and functional dependencies.

## BCNF considerations
The important candidate keys are enforced with unique constraints: user email, `(owner_id, farm name)`, and `(farm_id, field name)`. These constraints prevent alternate determinants from creating duplicate business entities.

## Deliberate JSON exception
`crop_predictions.alternatives_json` stores a variable-length ranked list returned by the ML model. Core relational facts remain normalized; this JSON field is a bounded prediction payload rather than a substitute for relational entities.
