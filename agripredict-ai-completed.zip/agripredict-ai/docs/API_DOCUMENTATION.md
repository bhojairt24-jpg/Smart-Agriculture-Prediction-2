# API Documentation

FastAPI generates the authoritative interactive schema at `/docs` and `/openapi.json`.

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/auth/register` | Farmer/expert registration. |
| POST | `/api/auth/login` | JWT login. |
| GET | `/api/auth/me` | Current user. |
| GET/POST | `/api/farms` | List/create farms. |
| GET/PUT/DELETE | `/api/farms/{farm_id}` | Farm operations with ownership checks. |
| GET/POST | `/api/farms/{farm_id}/fields` | Field operations. |
| POST | `/api/soil/upload` | Soil PDF/image upload + OCR extraction. |
| POST | `/api/soil/analyze` | Save verified soil values. |
| GET | `/api/soil/{farm_id}` | Soil history. |
| POST | `/api/predictions/crop` | Crop recommendation. |
| POST | `/api/predictions/yield` | Yield prediction. |
| POST | `/api/predictions/irrigation` | Irrigation recommendation. |
| POST | `/api/disease/analyze` | Disease image screening. |
| GET | `/api/weather/{farm_id}` | Weather snapshot/forecast. |
| GET | `/api/dashboard/{farm_id}` | Dashboard aggregate. |
| GET | `/api/analytics/{farm_id}` | Historical analytics. |
| GET/PUT | `/api/alerts`, `/api/alerts/{id}/read` | Alert management. |
| POST | `/api/assistant/chat` | Farm-context assistant. |
| POST/GET | `/api/reports/generate`, `/api/reports/{id}/download` | PDF reports. |
| GET | `/api/admin/overview` | Admin-only ADBMS summary using PostgreSQL views. |

Protected endpoints require `Authorization: Bearer <JWT>`.
