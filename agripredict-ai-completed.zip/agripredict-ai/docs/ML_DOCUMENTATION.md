# ML Documentation

## Crop recommendation
Random Forest classification using N, P, K, temperature, humidity, pH and rainfall. The supplied artifact is trained on generated demonstration data. It returns a recommendation, confidence, and ranked alternatives.

## Yield prediction
Random Forest regression uses crop encoding, rainfall, temperature, pH, N, P, K, irrigation and season. Yield is returned in tonnes/hectare and converted to total production using the farm area.

## Irrigation
The current advisor is deliberately rule-based rather than falsely labeled ML. It combines soil moisture, temperature, humidity, crop stage, rain probability and expected rainfall.

## Disease detection
The service supports MobileNetV2 inference when a trained `disease_mobilenetv2.pt` artifact and class list are present. Otherwise DEMO_MODE returns a clearly flagged sample result.

## Model limitations
The included crop/yield models are trained on generated demo datasets. Their metrics are demonstrations of the ML pipeline, not evidence of regional agronomic accuracy. Production use requires validated, region-specific datasets, independent evaluation, monitoring and expert review.
