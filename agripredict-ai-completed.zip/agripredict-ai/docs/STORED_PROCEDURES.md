# PostgreSQL Functions and Stored Procedure

## Functions

- `fn_soil_status(ph, moisture, organic_carbon)` classifies the latest soil observation using a documented deterministic rule.
- `fn_farm_health_score(ph, moisture, humidity)` calculates the platform's transparent dashboard health score.

Both are immutable for the same inputs and are useful in reporting SQL without duplicating business expressions.

## Stored procedure

`sp_finalize_yield_prediction(farm_id, crop, yield_tph, total_production_tonnes)` inserts a finalized yield prediction as one database operation.

The FastAPI yield endpoint calls this procedure on PostgreSQL. The SQLite-only automated test environment uses the equivalent ORM insert because SQLite has no compatible PostgreSQL stored-procedure implementation. This is explicitly an environment adapter, not a second production database.
