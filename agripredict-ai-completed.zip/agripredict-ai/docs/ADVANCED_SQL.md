# Advanced PostgreSQL SQL Demonstration

These queries use the actual AgriPredict schema.

## 1. INNER JOIN – farm ownership
```sql
SELECT f.id, f.name, u.name AS farmer
FROM farms f
INNER JOIN users u ON u.id = f.owner_id
ORDER BY f.name;
```

## 2. LEFT JOIN – farms with zero fields included
```sql
SELECT f.name, COUNT(fi.id) AS field_count
FROM farms f
LEFT JOIN fields fi ON fi.farm_id = f.id
GROUP BY f.id, f.name
ORDER BY field_count DESC;
```

## 3. GROUP BY + HAVING – active prediction farms
```sql
SELECT f.id, f.name, COUNT(cp.id) AS predictions
FROM farms f
JOIN crop_predictions cp ON cp.farm_id = f.id
GROUP BY f.id, f.name
HAVING COUNT(cp.id) >= 1;
```

## 4. CASE – soil condition
```sql
SELECT id, farm_id,
       CASE
         WHEN ph BETWEEN 5.5 AND 7.5 AND moisture BETWEEN 25 AND 70 THEN 'Good'
         WHEN ph BETWEEN 5 AND 8 THEN 'Needs attention'
         ELSE 'Critical'
       END AS soil_status
FROM soil_tests;
```

## 5. Subquery – latest yield per farm
```sql
SELECT f.name, y.yield_tph
FROM farms f
JOIN yield_predictions y ON y.id = (
  SELECT y2.id FROM yield_predictions y2
  WHERE y2.farm_id = f.id
  ORDER BY y2.created_at DESC LIMIT 1
);
```

## 6. CTE – average predicted yield by crop
```sql
WITH crop_yields AS (
  SELECT crop, AVG(yield_tph) AS avg_yield
  FROM yield_predictions
  GROUP BY crop
)
SELECT crop, ROUND(avg_yield::numeric, 2) AS avg_yield_tph
FROM crop_yields
ORDER BY avg_yield DESC;
```

## 7. Window function – rank predictions within each farm
```sql
SELECT farm_id, recommended_crop, confidence,
       RANK() OVER (PARTITION BY farm_id ORDER BY confidence DESC) AS confidence_rank
FROM crop_predictions;
```

## 8. Date aggregation
```sql
SELECT DATE_TRUNC('day', created_at) AS day, COUNT(*) AS predictions
FROM crop_predictions
GROUP BY 1
ORDER BY 1;
```

## 9. Database view
```sql
SELECT * FROM farm_summary ORDER BY unread_alert_count DESC;
SELECT * FROM latest_soil_status;
```

These queries demonstrate joins, aggregation, HAVING, CASE, subqueries, CTEs, window functions, date functions, and views using real project entities.
