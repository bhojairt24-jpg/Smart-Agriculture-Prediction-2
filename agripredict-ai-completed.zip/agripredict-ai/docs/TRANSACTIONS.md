# Transactions

SQLAlchemy sessions are used as transaction boundaries for multi-step writes.

Examples:

1. Soil analysis creates a `soil_tests` row and its related `soil_readings` row; both commit together. A failure rolls the session back.
2. Crop prediction stores the prediction and its related alert in one transaction.
3. Farm/field creation commits only after validation and uniqueness checks succeed.
4. Yield finalization calls the PostgreSQL stored procedure inside the same request transaction.
5. Report metadata is committed only after the PDF has been successfully generated.

A transaction test should intentionally violate a constraint and verify that no partial child record remains.
