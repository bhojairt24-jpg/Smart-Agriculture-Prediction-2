# Security

- Passwords use bcrypt when the package is available; a scrypt fallback is retained for constrained demo environments and legacy seeded data remains verifiable.
- JWTs contain user ID, role, and expiration. The backend validates the signature and expiration on every protected request.
- Authorization is enforced server-side with farm ownership checks. Changing a `farm_id` in the browser does not grant access to another farmer's farm.
- Admin access is enforced with a backend role dependency. Public registration cannot self-assign `admin`.
- SQLAlchemy parameterizes ORM queries; PostgreSQL functions/procedures use explicit typed parameters.
- Secrets are loaded from environment variables and `.env` is excluded from source control. `.env.example` contains placeholders only.
- Uploads are extension/size validated and stored under randomized filenames. Disease images are restricted to JPG/JPEG/PNG; soil reports support PDF/JPG/JPEG/PNG.
- External weather/LLM credentials stay on the backend.
- Demo results are explicitly marked and are not presented as agronomic guarantees.

For production, add HTTPS, rate limiting, malware scanning for uploads, secret management, token revocation/rotation, and managed object storage.
