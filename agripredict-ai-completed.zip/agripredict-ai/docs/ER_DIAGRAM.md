# ER Diagram

The following Mermaid ER diagram is generated from the implemented SQLAlchemy schema and migration design.

```mermaid
erDiagram
    USERS ||--o{ FARMS : owns
    FARMS ||--o{ FIELDS : contains
    FARMS ||--o{ SOIL_TESTS : has
    FARMS ||--o{ SOIL_READINGS : records
    FARMS ||--o{ WEATHER_DATA : records
    FARMS ||--o{ CROP_PREDICTIONS : receives
    FARMS ||--o{ YIELD_PREDICTIONS : receives
    FARMS ||--o{ IRRIGATION_PREDICTIONS : receives
    FARMS ||--o{ DISEASE_SCANS : receives
    FARMS ||--o{ ALERTS : generates
    FARMS ||--o{ REPORTS : produces
    USERS ||--o{ CHAT_HISTORY : creates
    FARMS ||--o{ CHAT_HISTORY : contextualizes

    USERS {
      int id PK
      string name
      string email UK
      string password_hash
      string role
      datetime created_at
    }
    FARMS {
      int id PK
      int owner_id FK
      string name
      string location
      float latitude
      float longitude
      float area_acres
      string soil_type
      string current_crop
      string season
      datetime created_at
      datetime updated_at
    }
    FIELDS {
      int id PK
      int farm_id FK
      string name
      float area_acres
      string crop
    }
    SOIL_TESTS {
      int id PK
      int farm_id FK
      float nitrogen
      float phosphorus
      float potassium
      float ph
      float organic_carbon
      float moisture
      string source
      boolean verified
      datetime created_at
      datetime updated_at
    }
    SOIL_READINGS {
      int id PK
      int farm_id FK
      float moisture
      datetime recorded_at
    }
    WEATHER_DATA {
      int id PK
      int farm_id FK
      float temperature
      float humidity
      float wind_kmh
      float rainfall_mm
      float rain_probability
      string condition
      datetime recorded_at
    }
    CROP_PREDICTIONS {
      int id PK
      int farm_id FK
      string recommended_crop
      float confidence
      text alternatives_json
      datetime created_at
    }
    YIELD_PREDICTIONS {
      int id PK
      int farm_id FK
      string crop
      float yield_tph
      float total_production_tonnes
      datetime created_at
    }
    IRRIGATION_PREDICTIONS {
      int id PK
      int farm_id FK
      boolean required
      text reason
      text action
      float water_liters
      datetime created_at
    }
    DISEASE_SCANS {
      int id PK
      int farm_id FK
      string filename
      string disease
      float confidence
      string severity
      text guidance
      boolean demo_mode
      datetime created_at
    }
    ALERTS {
      int id PK
      int farm_id FK
      string kind
      string title
      text message
      boolean is_read
      datetime created_at
    }
    REPORTS {
      int id PK
      int farm_id FK
      string filename
      string path
      datetime created_at
    }
    CHAT_HISTORY {
      int id PK
      int user_id FK
      int farm_id FK
      text message
      text response
      datetime created_at
    }
