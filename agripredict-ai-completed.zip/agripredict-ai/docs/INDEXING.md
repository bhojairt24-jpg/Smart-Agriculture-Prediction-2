# Indexing Strategy

Indexes are based on real application access patterns rather than indexing every column.

| Index | Purpose |
|---|---|
| `users.email` | Fast login lookup and unique identity enforcement. |
| `users.role` | Admin/role reporting and filtering. |
| `farms.owner_id` | Farmer's farm list and authorization checks. |
| `farms(latitude, longitude)` | Location-based farm/weather lookup. |
| `fields.farm_id` | Field list for a farm. |
| `soil_tests(farm_id, created_at)` | Latest soil test and history queries. |
| `soil_readings(farm_id, recorded_at)` | Time-series moisture charts. |
| `weather_data(farm_id, recorded_at)` | Latest weather/history lookup. |
| Prediction tables `(farm_id, created_at)` | Latest prediction and analytics history. |
| `alerts(farm_id, is_read, created_at)` | Unread/recent alert retrieval. |
| `reports(farm_id, created_at)` | Report history. |
| `chat_history(user_id, created_at)` / farm index | User/farm chat history. |
| `audit_logs(table_name, record_id)` and `created_at` | Record-specific and chronological audit review. |

## Trade-off
Indexes speed reads but add write cost and storage. AgriPredict therefore indexes foreign keys and the timestamp/filter combinations used by dashboard/history queries, not low-selectivity descriptive columns such as `soil_type`.

## EXPLAIN examples

```sql
EXPLAIN ANALYZE
SELECT * FROM soil_tests
WHERE farm_id = 1
ORDER BY created_at DESC
LIMIT 1;

EXPLAIN ANALYZE
SELECT * FROM alerts
WHERE farm_id = 1 AND is_read = false
ORDER BY created_at DESC;
```

On a populated PostgreSQL database, these plans can be compared before/after index creation to demonstrate index usage and cost.
