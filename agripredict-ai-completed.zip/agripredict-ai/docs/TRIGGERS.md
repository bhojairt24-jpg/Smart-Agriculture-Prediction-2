# PostgreSQL Triggers

## `trg_farms_updated_at` / `trg_soil_tests_updated_at`
**Event:** BEFORE UPDATE.  
**Function:** `fn_touch_updated_at`.  
**Purpose:** keeps modification timestamps database-controlled.

## `trg_<table>_audit`
**Event:** AFTER INSERT, UPDATE, DELETE on core business tables.  
**Function:** `fn_audit_row`.  
**Purpose:** records old/new row JSON and the operation in `audit_logs`, providing an examiner-visible change history without storing passwords as application secrets.

The audit trigger is intentionally database-side so direct SQL changes are also observable.
