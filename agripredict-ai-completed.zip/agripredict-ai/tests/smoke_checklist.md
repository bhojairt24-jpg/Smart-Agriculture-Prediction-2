# Manual E2E smoke test
1. Login with demo credentials.
2. Dashboard loads stats/chart/forecast/insights.
3. Add/edit/delete a farm.
4. Soil Analysis: upload a PDF/image or enter values, verify and analyze.
5. Soil Result page shows nutrient cards and health score.
6. Crop Recommendation returns model recommendation and alternatives.
7. Yield Prediction returns yield and total production.
8. Irrigation Advisor returns transparent rule-based recommendation.
9. Disease Detection accepts a valid image and returns model/demo output.
10. Weather shows current conditions and forecast.
11. Analytics shows stored trends.
12. Assistant answers a farm-context question.
13. Generate PDF from Swagger or extend the Reports UI if desired.
14. Check `/docs`, logout, and confirm protected APIs reject anonymous access.
