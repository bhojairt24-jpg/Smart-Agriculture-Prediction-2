import os
os.environ["DATABASE_URL"]="sqlite:///./test_agripredict.db"; os.environ["DEMO_MODE"]="true"; os.environ["JWT_SECRET"]="test-secret-32-bytes-long-1234567890"
from fastapi.testclient import TestClient
from app.main import app
from app.database.session import Base,engine
from app.utils.seed import seed
import pytest
@pytest.fixture(scope="session",autouse=True)
def setup(): Base.metadata.drop_all(engine); Base.metadata.create_all(engine); seed(); yield; Base.metadata.drop_all(engine)
@pytest.fixture
def client(): return TestClient(app)
@pytest.fixture
def auth(client):
    r=client.post('/api/auth/login',json={'email':'demo@agripredict.ai','password':'Demo@12345'}); return {'Authorization':f"Bearer {r.json()['access_token']}"}
