def test_health(client): assert client.get('/health').json()['status']=='healthy'
def test_login(client,auth): assert 'Authorization' in auth
def test_me(client,auth): assert client.get('/api/auth/me',headers=auth).status_code==200
def test_farms(client,auth):
    r=client.get('/api/farms',headers=auth); assert r.status_code==200 and len(r.json())>=1
def test_farm_create(client,auth):
    data={'name':'Test Farm','location':'Nashik, Maharashtra','latitude':20.0,'longitude':73.8,'area_acres':2,'soil_type':'Black Soil','current_crop':'Cotton','season':'Kharif'}; r=client.post('/api/farms',headers=auth,json=data); assert r.status_code==201; assert r.json()['name']=='Test Farm'
def test_soil_validation(client,auth):
    r=client.post('/api/soil/analyze',headers=auth,json={'farm_id':1,'nitrogen':82,'phosphorus':35,'potassium':48,'ph':6.7,'organic_carbon':.72,'moisture':42,'verified':True}); assert r.status_code==200
def test_crop_prediction(client,auth):
    r=client.post('/api/predictions/crop',headers=auth,json={'farm_id':1,'nitrogen':82,'phosphorus':35,'potassium':48,'temperature':26,'humidity':80,'ph':6.7,'rainfall':200}); assert r.status_code==200; assert r.json()['recommended_crop']
def test_yield_prediction(client,auth):
    r=client.post('/api/predictions/yield',headers=auth,json={'farm_id':1,'crop':'Rice','area_acres':5,'rainfall':200,'temperature':27,'ph':6.4,'nitrogen':68,'phosphorus':35,'potassium':48,'irrigation':True,'season':'Kharif'}); assert r.status_code==200; assert r.json()['yield_tph']>0
def test_irrigation(client,auth):
    r=client.post('/api/predictions/irrigation',headers=auth,json={'farm_id':1,'soil_moisture':32,'temperature':30,'humidity':65,'crop':'Rice','growth_stage':'Flowering','rain_probability':70,'expected_rainfall':7}); assert r.status_code==200; assert 'required' in r.json()
def test_weather(client,auth): assert client.get('/api/weather/1',headers=auth).status_code==200
def test_disease_requires_image(client,auth):
    r=client.post('/api/disease/analyze?farm_id=1',headers=auth,files={'file':('bad.txt',b'x','text/plain')}); assert r.status_code==415
def test_authorization(client): assert client.get('/api/farms').status_code==401

def test_register_cannot_self_assign_admin(client):
    r = client.post('/api/auth/register', json={'name':'Bad Admin','email':'badadmin@example.com','password':'Password123!','role':'admin'})
    assert r.status_code == 422


def test_soil_ocr_provenance_is_preserved(client, auth):
    r = client.post('/api/soil/analyze', headers=auth, json={'farm_id':1,'nitrogen':80,'phosphorus':30,'potassium':45,'ph':6.5,'organic_carbon':0.8,'moisture':40,'verified':True,'source':'ocr'})
    assert r.status_code == 200
    assert r.json()['values']['source'] == 'ocr'
    history = client.get('/api/soil/1', headers=auth)
    assert history.status_code == 200 and history.json()[0]['source'] == 'ocr'


def test_farm_ownership_is_enforced(client, auth):
    reg = client.post('/api/auth/register', json={'name':'Other Farmer','email':'other@example.com','password':'Password123!','role':'farmer'})
    other = {'Authorization': f"Bearer {reg.json()['access_token']}"}
    r = client.get('/api/farms/1', headers=other)
    assert r.status_code == 403
    assert client.get('/api/farms/1', headers=auth).status_code == 200


def test_invalid_soil_source_is_rejected(client, auth):
    r = client.post('/api/soil/analyze', headers=auth, json={'farm_id':1,'nitrogen':80,'phosphorus':30,'potassium':45,'ph':6.5,'organic_carbon':0.8,'moisture':40,'verified':False,'source':'guess'})
    assert r.status_code == 422

def test_duplicate_farm_is_rejected_without_partial_write(client, auth):
    payload={'name':'Green Valley Farm','location':'Pune, Maharashtra','latitude':18.5204,'longitude':73.8567,'area_acres':5,'soil_type':'Loamy','current_crop':'Rice','season':'Kharif'}
    before = len(client.get('/api/farms', headers=auth).json())
    r = client.post('/api/farms', headers=auth, json=payload)
    after = len(client.get('/api/farms', headers=auth).json())
    assert r.status_code == 409 and before == after


def test_valid_disease_image_demo_path(client, auth):
    with open('tests/fixtures/leaf.png', 'rb') as fh:
        r = client.post('/api/disease/analyze?farm_id=1', headers=auth, files={'file':('leaf.png', fh, 'image/png')})
    assert r.status_code == 200
    assert 'disease' in r.json() and r.json()['demo_mode'] is True


def test_report_generation_and_download(client, auth):
    r = client.post('/api/reports/generate', headers=auth, json={'farm_id':1})
    assert r.status_code == 200
    report_id = r.json()['report_id']
    d = client.get(f'/api/reports/{report_id}/download', headers=auth)
    assert d.status_code == 200 and d.headers['content-type'].startswith('application/pdf')


def test_admin_overview_is_role_protected(client):
    farmer = client.post('/api/auth/login', json={'email':'demo@agripredict.ai','password':'Demo@12345'}).json()['access_token']
    admin = client.post('/api/auth/login', json={'email':'admin@agripredict.ai','password':'Admin@12345'}).json()['access_token']
    assert client.get('/api/admin/overview', headers={'Authorization':f'Bearer {farmer}'}).status_code == 403
    r = client.get('/api/admin/overview', headers={'Authorization':f'Bearer {admin}'})
    assert r.status_code == 200 and r.json()['totals']['farms'] >= 1

def test_disease_rejects_invalid_image_content(client, auth):
    r = client.post('/api/disease/analyze?farm_id=1', headers=auth, files={'file':('fake.png',b'not-an-image','image/png')})
    assert r.status_code == 415
