# AgriPredict AI – Smart Agriculture Prediction Platform

A university capstone-ready full-stack agricultural decision-support platform inspired by the supplied reference UI. It combines React/Vite, FastAPI, PostgreSQL, scikit-learn models, optional PyTorch disease inference, weather integration, charts, maps, PDF reports, alerts, and an explainable AI assistant fallback.

> **Important:** The included ML artifacts are trained on a clearly labeled demo dataset generated for local demonstration. They are not agronomic-grade models and must not be presented as scientifically validated. The disease module uses a real transfer-learning architecture when a trained artifact is supplied, with a transparent DEMO_MODE fallback otherwise.

## 1. Features
- Reference-inspired green agricultural SaaS UI with sidebar/topbar/cards.
- Login/register/logout with JWT and bcrypt password hashing with a constrained-environment scrypt fallback.
- Farmer, Agricultural Expert, and Admin roles (Farmer flow prioritized).
- Farm CRUD, field management, coordinates and Leaflet map.
- Soil analysis by manual entry or PDF/image upload with optional OCR and verification step.
- Crop recommendation: real scikit-learn Random Forest artifact with top alternatives.
- Yield prediction: real scikit-learn Random Forest regression artifact.
- Irrigation advisor: transparent rule-based engine, explicitly not labeled ML.
- Disease detection: MobileNetV2 training/inference architecture with local fallback in demo mode.
- Real weather integration using Open-Meteo by default; WeatherAPI-compatible provider is configurable.
- Plotly analytics and dashboard data from APIs.
- Alerts stored in the database.
- Context-aware agriculture assistant with optional LLM and deterministic fallback.
- Professional PDF farm reports.
- Demo mode so the application remains usable without external API keys or a disease model.
- Docker Compose for frontend + backend + PostgreSQL.
- FastAPI Swagger docs at `/docs`.
- Pytest backend coverage for core API workflows.

## 2. Technology Stack
**Frontend:** React 18, Vite, Tailwind CSS, React Router, Axios, Plotly, React Leaflet, Lucide React.

**Backend:** Python 3.11+, FastAPI, Pydantic v2, SQLAlchemy 2, Alembic, PyJWT, bcrypt, python-multipart.

**Database:** PostgreSQL 16 (SQLite is used only by the automated test suite).

**ML/CV:** pandas, NumPy, scikit-learn, joblib, Pillow, optional OpenCV/Tesseract, optional PyTorch + torchvision for disease model training.

**Reports:** ReportLab.

## 3. Architecture
```text
Browser
  |
  v
React/Vite SPA ---- Axios ----> FastAPI REST API
                                  |
             +--------------------+---------------------+
             |                    |                     |
          SQLAlchemy           ML services          External services
             |              crop/yield/disease       weather/LLM
             v                    |                     |
        PostgreSQL          local model files        optional
```

The backend keeps route handlers thin. Business logic lives in services; ML models are loaded once and cached; all external integrations have fallback behavior in `DEMO_MODE`.

## 4. Folder Structure
```text
agripredict-ai/
├── frontend/                 # React/Vite client
├── backend/                  # FastAPI application
│   ├── app/api/routes/       # REST routes
│   ├── app/models/           # SQLAlchemy models
│   ├── app/schemas/          # Pydantic schemas
│   ├── app/services/         # domain/external services
│   ├── app/ml/               # model inference adapters
│   ├── alembic/              # migrations
│   └── requirements.txt
├── ml/                       # training data/scripts and model outputs
├── tests/                    # backend pytest suite
├── uploads/                  # runtime uploads
├── reports/                  # generated PDFs
├── docker-compose.yml
├── .env.example
└── README.md
```

## 5. Environment Variables
Copy `.env.example` to `.env`.

Key settings:
- `DATABASE_URL=postgresql+psycopg://agripredict:agripredict@localhost:5432/agripredict` for local PostgreSQL; Docker overrides it with the `db` hostname.
- `JWT_SECRET` must be changed for non-demo use.
- `DEMO_MODE=true` keeps all major screens functional without external services.
- `WEATHER_PROVIDER=open_meteo` works without a key. Set `WEATHER_PROVIDER=weatherapi` and `WEATHER_API_KEY` for WeatherAPI.
- `LLM_PROVIDER=none` is the default. The assistant has a deterministic fallback.

## 6. Manual Installation
### Prerequisites
- Python 3.11 or newer
- Node.js 18 or newer
- PostgreSQL 14+

### Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
copy ..\\.env.example .env   # Windows PowerShell: Copy-Item ..\\.env.example .env
# Linux/macOS: cp ../.env.example .env
alembic upgrade head
python -m app.utils.seed
uvicorn app.main:app --reload --port 8000
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```
Open `http://localhost:5173`.

## 7. PostgreSQL Setup
Create a database/user matching your `.env`, for example:
```sql
CREATE USER agripredict WITH PASSWORD 'agripredict';
CREATE DATABASE agripredict OWNER agripredict;
```
Then run:
```bash
cd backend
alembic upgrade head
python -m app.utils.seed
```

## 8. Docker (recommended)
```bash
docker compose up --build
```
- Frontend: `http://localhost:5173`
- Backend: `http://localhost:8000`
- Swagger: `http://localhost:8000/docs`
- PostgreSQL: `localhost:5432`

The backend container runs migrations and seed data before starting.

## 9. Demo Login
**Development/demo credential only**
- Farmer email: `demo@agripredict.ai`
- Farmer password: `Demo@12345`
- Admin email: `admin@agripredict.ai`
- Admin password: `Admin@12345`

Never use this password in a deployed production system.

## 10. Major API Endpoints
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET/POST /api/farms`
- `GET/PUT/DELETE /api/farms/{id}`
- `POST /api/soil/upload`
- `POST /api/soil/analyze`
- `GET /api/soil/{farm_id}`
- `POST /api/predictions/crop`
- `POST /api/predictions/yield`
- `POST /api/predictions/irrigation`
- `POST /api/disease/analyze`
- `GET /api/weather/{farm_id}`
- `GET /api/dashboard/{farm_id}`
- `GET /api/analytics/{farm_id}`
- `GET /api/alerts`
- `PUT /api/alerts/{id}/read`
- `POST /api/assistant/chat`
- `POST /api/reports/generate`
- `GET /api/admin/overview` (admin only)

## 11. ML Training
### Crop recommendation
```bash
cd ml
python training/train_crop.py
```
Produces `backend/app/ml/artifacts/crop_model.joblib` and metrics JSON. The included demo dataset is generated by the script so there is no hidden external dataset.

### Yield prediction
```bash
python training/train_yield.py
```
Produces `backend/app/ml/artifacts/yield_model.joblib` and metrics JSON.

### Disease model
```bash
python training/train_disease.py --data-dir /path/to/plantvillage
```
The training script uses MobileNetV2 transfer learning when PyTorch/torchvision and a labeled image directory are available. It saves `disease_mobilenetv2.pt` plus class metadata. Without that artifact, DEMO_MODE returns a clearly marked demo result.

## 12. Model Evaluation
Training scripts print/save accuracy, precision, recall, F1 and confusion matrix for classification, and MAE, RMSE, R² for regression. **No model quality value is hard-coded into the UI.** The README treats the included generated data as demonstration-only.

## 13. OCR
The soil upload endpoint validates PDF/JPG/JPEG/PNG files. PDF text extraction uses `pypdf` if available. Image OCR uses `pytesseract` if the Tesseract executable is installed. If OCR is unavailable, DEMO_MODE returns sample values and the frontend explicitly asks the user to verify them. Extracted values are never silently treated as verified.

## 14. Weather
Open-Meteo is the default provider and does not require a secret. Provider abstraction also supports WeatherAPI through `WEATHER_PROVIDER=weatherapi` and `WEATHER_API_KEY`. API keys remain backend-only.

## 15. Testing
Backend tests use an isolated SQLite database only as a test adapter; PostgreSQL remains the primary application database. The project-level pytest configuration makes the documented command work from the repository root:
```bash
pytest -q
```
Frontend component tests are configured with Vitest/Testing Library. If Node dependencies are installed, run:
```bash
cd frontend
npm test
npm run build
```
An end-to-end smoke checklist is included in `tests/smoke_checklist.md` because browser automation packages are intentionally not required for the core distribution.

## 16. Troubleshooting
- **PostgreSQL connection error:** check `DATABASE_URL`, database user/password and that PostgreSQL is running.
- **CORS error:** set `FRONTEND_ORIGIN` to the exact frontend URL.
- **Weather unavailable:** keep `DEMO_MODE=true` or check provider/key.
- **Disease model unavailable:** train a model or keep demo mode enabled.
- **OCR unavailable:** install Tesseract; manual correction remains available.
- **Port occupied:** change ports in Docker Compose or dev commands.
- **Frontend dependency install fails offline:** run `npm install` on a networked machine; source files are complete but npm packages are intentionally not vendored.

## 17. Security Notes
Passwords are never stored in plaintext. JWTs protect APIs. SQLAlchemy parameterizes database access. Uploads have MIME/extension/size checks and randomized storage names. Secrets are environment variables. CORS is configurable. For production, use HTTPS, a secrets manager, stronger token rotation/revocation, object storage, antivirus scanning, rate limiting, and a managed PostgreSQL service.

## 18. ADBMS Concepts Demonstrated
- Normalized relational schema and referential integrity
- PostgreSQL indexes based on actual query patterns
- Reporting views (`farm_summary`, `latest_soil_status`, `prediction_summary`, `alert_summary`)
- PL/pgSQL functions and `sp_finalize_yield_prediction` procedure
- `updated_at` and row-audit triggers
- Audit log table
- Transactional multi-row writes
- Advanced SQL: joins, aggregation/HAVING, CASE, subqueries, CTEs, window functions and date functions
- Backend RBAC and ownership isolation

See `docs/DATABASE_DESIGN.md`, `docs/ER_DIAGRAM.md`, `docs/NORMALIZATION.md`, `docs/ADVANCED_SQL.md`, `docs/INDEXING.md`, `docs/STORED_PROCEDURES.md`, `docs/TRIGGERS.md`, `docs/TRANSACTIONS.md`, `docs/SECURITY.md`, `docs/API_DOCUMENTATION.md`, and `docs/ML_DOCUMENTATION.md`.

## 19. Limitations
- Demo ML data is not a substitute for region-specific agronomic validation.
- Disease demo mode is not a real clinical/agronomic diagnosis.
- Farm health is a transparent heuristic, not a scientifically validated index.
- LLM explanations are optional and should be treated as explanatory text, not authoritative measurements.

## 19. Future Enhancements
- Region-specific agronomic models and validation.
- Satellite/NDVI integration.
- IoT soil sensors.
- Model monitoring and drift detection.
- Expert review workflows.
- Push/SMS alerts.
- Role-specific admin dashboards.

## 20. Capstone Viva Explanation
The core architecture follows **validated data → deterministic/ML decision → database record → UI visualization → optional LLM explanation**. This makes the system easier to test and prevents the assistant from inventing critical measurements.
