"""Train a MobileNetV2 classifier from an ImageFolder-compatible dataset.
Example: python train_disease.py --data-dir /path/to/plantvillage
"""
import argparse
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--data-dir',required=True); ap.add_argument('--epochs',type=int,default=3); args=ap.parse_args()
    try:
        import torch
        from torchvision import datasets,models,transforms
        from torch.utils.data import DataLoader,random_split
    except Exception as e: raise SystemExit('Install the optional PyTorch/torchvision packages listed in ml/training/requirements-disease.txt') from e
    data=Path(args.data_dir); tf=transforms.Compose([transforms.Resize((224,224)),transforms.RandomHorizontalFlip(),transforms.ToTensor(),transforms.Normalize([.485,.456,.406],[.229,.224,.225])]); ds=datasets.ImageFolder(data,transform=tf); n=max(1,int(.8*len(ds))); tr,va=random_split(ds,[n,len(ds)-n]); tl=DataLoader(tr,batch_size=32,shuffle=True); vl=DataLoader(va,batch_size=32); model=models.mobilenet_v2(weights=models.MobileNet_V2_Weights.DEFAULT); model.classifier[1]=torch.nn.Linear(model.last_channel,len(ds.classes)); opt=torch.optim.Adam(model.parameters(),lr=1e-4); lossfn=torch.nn.CrossEntropyLoss(); model.train()
    for ep in range(args.epochs):
        for x,y in tl: opt.zero_grad(); loss=lossfn(model(x),y); loss.backward(); opt.step()
    out=Path(__file__).resolve().parents[2]/'backend/app/ml/artifacts'; out.mkdir(parents=True,exist_ok=True); torch.save(model.state_dict(),out/'disease_mobilenetv2.pt'); (out/'disease_classes.txt').write_text('\n'.join(ds.classes)); print('Saved disease model and classes. Evaluate on a held-out test set before claiming production quality.')
if __name__=='__main__': main()
