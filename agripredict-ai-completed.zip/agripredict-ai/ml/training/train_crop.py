from pathlib import Path
import json, numpy as np, pandas as pd, joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,precision_recall_fscore_support,confusion_matrix
ROOT=Path(__file__).resolve().parents[2]; OUT=ROOT/'backend/app/ml/artifacts'; OUT.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(42); crops=["Rice","Maize","Chickpea","Cotton"]
rows=[]
for _ in range(800):
    crop=rng.choice(crops); base={"Rice":(80,35,45,27,78,6.5,220),"Maize":(75,40,40,25,65,6.2,150),"Chickpea":(45,55,35,23,45,7.0,80),"Cotton":(60,35,55,29,55,7.0,100)}[crop]
    vals=[max(0,rng.normal(v, v*.12 if v else .1)) for v in base]; rows.append(vals+[crop])
df=pd.DataFrame(rows,columns=["nitrogen","phosphorus","potassium","temperature","humidity","ph","rainfall","crop"]); df.to_csv(ROOT/'ml/datasets/crop_demo.csv',index=False)
X=df.iloc[:,:7]; y=df.crop; Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42,stratify=y); m=RandomForestClassifier(n_estimators=180,random_state=42).fit(Xtr,ytr); pred=m.predict(Xte); p,r,f,_=precision_recall_fscore_support(yte,pred,average='weighted',zero_division=0); metrics={"accuracy":accuracy_score(yte,pred),"precision":p,"recall":r,"f1":f,"confusion_matrix":confusion_matrix(yte,pred).tolist(),"dataset":"generated demo data; replace with validated agronomic data"}; joblib.dump(m,OUT/'crop_model.joblib'); (OUT/'crop_meta.json').write_text(json.dumps(metrics,indent=2)); print(json.dumps(metrics,indent=2))
if __name__=='__main__': pass
