from pathlib import Path
import json,numpy as np,pandas as pd,joblib
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error,mean_squared_error,r2_score
ROOT=Path(__file__).resolve().parents[2]; OUT=ROOT/'backend/app/ml/artifacts'; OUT.mkdir(parents=True,exist_ok=True); rng=np.random.default_rng(7); rows=[]
for _ in range(1000):
    crop=int(rng.integers(1,6)); rain=rng.uniform(40,350); temp=rng.uniform(18,36); ph=rng.uniform(5,8); n=rng.uniform(20,140); p=rng.uniform(10,80); k=rng.uniform(15,100); irr=int(rng.integers(0,2)); season=int(rng.integers(0,2)); y=2+.015*n+.01*p+.008*k+.002*rain-.15*abs(ph-6.5)+.6*irr+.2*(crop==1)+rng.normal(0,.18); rows.append([crop,rain,temp,ph,n,p,k,irr,season,max(.4,min(9,y))])
df=pd.DataFrame(rows,columns=["crop","rainfall","temperature","ph","nitrogen","phosphorus","potassium","irrigation","season","yield_tph"]); df.to_csv(ROOT/'ml/datasets/yield_demo.csv',index=False); X=df.iloc[:,:9]; y=df.yield_tph; Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42); m=RandomForestRegressor(n_estimators=200,random_state=42,n_jobs=-1).fit(Xtr,ytr); pred=m.predict(Xte); metrics={"mae":mean_absolute_error(yte,pred),"rmse":mean_squared_error(yte,pred)**.5,"r2":r2_score(yte,pred),"dataset":"generated demo data; replace with validated agronomic data"}; joblib.dump(m,OUT/'yield_model.joblib'); (OUT/'yield_meta.json').write_text(json.dumps(metrics,indent=2)); print(json.dumps(metrics,indent=2))
