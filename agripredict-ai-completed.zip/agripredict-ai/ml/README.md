# ML assets

The crop and yield scripts generate transparent demo datasets and train actual scikit-learn artifacts. Replace those datasets with validated regional data before making performance claims.

The disease script uses MobileNetV2 transfer learning. Place an ImageFolder-compatible dataset at a local path and train with `python ml/training/train_disease.py --data-dir ...`.
